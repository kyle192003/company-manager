/**
 * Tests for the project endpoints.
 * REQUIREMENTS covered: create a project with all its fields, search projects by name.
 */

import test from "node:test";
import assert from "node:assert/strict";

import { listProjects, getProject, createProject } from "../src/projects.js";
import { makeDb, TODAY, validProjectInput } from "./helpers.js";

test("the list returns every project, newest start date first", () => {
  const { status, body } = listProjects(makeDb(), {}, TODAY);

  assert.equal(status, 200);
  assert.deepEqual(body.map((project) => project.id), ["prj-2", "prj-1"]);
});

test("REQUIREMENT: projects can be searched by name", () => {
  const { body } = listProjects(makeDb(), { search: "portal" }, TODAY);

  assert.equal(body.length, 1);
  assert.equal(body[0].id, "prj-1");
});

test("LOGIC CHECK: each project reports whether it has already started", () => {
  const { body } = listProjects(makeDb(), {}, TODAY);
  const byId = Object.fromEntries(body.map((project) => [project.id, project]));

  // prj-1 began 2026-06-01, prj-2 begins 2026-11-03.
  assert.equal(byId["prj-1"].hasStarted, true);
  assert.equal(byId["prj-2"].hasStarted, false);
});

test("projects come back with their employees' full records, not just ids", () => {
  const { body } = getProject(makeDb(), "prj-1", TODAY);

  assert.deepEqual(body.employees.map((employee) => employee.firstName), ["Maria", "Paolo"]);
});

test("REQUIREMENT: a project can be created with all of its fields", () => {
  const db = makeDb();
  const { status, body, nextDb } = createProject(db, validProjectInput(), TODAY);

  assert.equal(status, 201);
  assert.equal(body.id, "prj-3");
  assert.equal(body.name, "Internal API Gateway");
  assert.equal(body.complexity, "high");
  assert.equal(body.startDate, "2026-12-01");
  assert.deepEqual(body.employeeIds, ["emp-1"]);
  assert.equal(nextDb.projects.length, 3);
});

test("LOGIC CHECK: creating a project with no employees is refused with 400", () => {
  const db = makeDb();
  const { status, body, nextDb } = createProject(db, validProjectInput({ employeeIds: [] }), TODAY);

  assert.equal(status, 400);
  assert.match(body.errors.employeeIds, /at least one employee/);
  assert.equal(nextDb, undefined);
});

test("creating a project with an unknown employee is refused with 400", () => {
  const { status, body } = createProject(
    makeDb(),
    validProjectInput({ employeeIds: ["emp-999"] }),
    TODAY,
  );

  assert.equal(status, 400);
  assert.match(body.errors.employeeIds, /emp-999/);
});

test("a duplicated employee id is stored only once", () => {
  const { body } = createProject(
    makeDb(),
    validProjectInput({ employeeIds: ["emp-1", "emp-1", "emp-2"] }),
    TODAY,
  );

  assert.deepEqual(body.employeeIds, ["emp-1", "emp-2"]);
});

test("a project created with a past start date saves, but returns a warning", () => {
  const { status, body } = createProject(
    makeDb(),
    validProjectInput({ startDate: "2026-01-05" }),
    TODAY,
  );

  assert.equal(status, 201);
  assert.equal(body.hasStarted, true);
  assert.equal(body.warnings.some((warning) => /already started/.test(warning)), true);
});

test("asking for a project that does not exist returns 404", () => {
  assert.equal(getProject(makeDb(), "prj-999", TODAY).status, 404);
});
