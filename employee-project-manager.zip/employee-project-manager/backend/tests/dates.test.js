/**
 * Tests for the start-date rule.
 * LOGIC CHECK: "UI must indicate if a project has already started based on the start date."
 */

import test from "node:test";
import assert from "node:assert/strict";

import { hasStarted, describeStart, isValidDateString, daysBetween } from "../src/utils/dates.js";
import { TODAY } from "./helpers.js";

test("a project starting before today counts as started", () => {
  assert.equal(hasStarted("2026-06-01", TODAY), true);
});

test("a project starting today counts as started", () => {
  assert.equal(hasStarted(TODAY, TODAY), true);
});

test("a project starting tomorrow has not started", () => {
  assert.equal(hasStarted("2026-09-23", TODAY), false);
});

test("describeStart labels a future project with the days remaining", () => {
  const status = describeStart("2026-10-05", TODAY);
  assert.equal(status.started, false);
  assert.equal(status.days, 13);
  assert.equal(status.label, "Starts in 13 days");
});

test("describeStart labels a project starting today rather than counting days", () => {
  const status = describeStart(TODAY, TODAY);
  assert.equal(status.started, true);
  assert.equal(status.label, "Starts today");
});

test("describeStart uses the singular for exactly one day", () => {
  assert.equal(describeStart("2026-09-23", TODAY).label, "Starts in 1 day");
  assert.equal(describeStart("2026-09-21", TODAY).label, "Started 1 day ago");
});

test("impossible dates are rejected instead of rolling over into the next month", () => {
  assert.equal(isValidDateString("2026-02-30"), false);
  assert.equal(isValidDateString("2026-13-01"), false);
  assert.equal(isValidDateString("05/10/2026"), false);
  assert.equal(isValidDateString("2026-02-28"), true);
});

test("daysBetween counts across a month boundary", () => {
  assert.equal(daysBetween("2026-09-22", "2026-10-05"), 13);
  assert.equal(daysBetween("2026-10-05", "2026-09-22"), -13);
});
