/**
 * Tests for the JSON-file database itself.
 *
 * DB_FILE is set before importing db.js, so every test here runs against a
 * throwaway file in the system temp folder and the real data/db.json is never
 * touched.
 */

import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";

const temporaryFile = path.join(
  fs.mkdtempSync(path.join(os.tmpdir(), "epm-test-")),
  "db.json",
);
process.env.DB_FILE = temporaryFile;

// Imported after DB_FILE is set, so the module picks up the test path.
const { readDb, writeDb, resetDb, nextId } = await import("../src/db.js");

test("the database is created from the seed file when it does not exist yet", () => {
  fs.rmSync(temporaryFile, { force: true });

  const db = readDb();
  assert.equal(fs.existsSync(temporaryFile), true);
  assert.ok(db.employees.length > 0);
  assert.ok(db.projects.length > 0);
  assert.ok(db.departments.includes("Engineering"));
});

test("what is written can be read back", () => {
  resetDb();
  const db = readDb();
  db.employees.push({
    id: "emp-999",
    firstName: "Test",
    lastName: "Person",
    email: "test.person@example.com",
    position: "Tester",
    department: "Engineering",
    hireDate: "2026-01-01",
  });
  writeDb(db);

  assert.equal(readDb().employees.some((employee) => employee.id === "emp-999"), true);
});

test("resetting restores the seed data and drops the change", () => {
  resetDb();
  assert.equal(readDb().employees.some((employee) => employee.id === "emp-999"), false);
});

test("the seed data is self-consistent: every project member is a real employee", () => {
  const db = readDb();
  const ids = new Set(db.employees.map((employee) => employee.id));

  for (const project of db.projects) {
    // LOGIC CHECK: the sample data must obey the same rule as new projects.
    assert.ok(project.employeeIds.length > 0, `${project.name} has no employees`);
    for (const id of project.employeeIds) {
      assert.ok(ids.has(id), `${project.name} refers to missing employee ${id}`);
    }
  }
});

test("every seeded employee has an avatar to show", () => {
  for (const employee of readDb().employees) {
    assert.match(
      employee.photoUrl,
      /^avatars\/emp-\d+\.svg$/,
      `${employee.email} has no usable photoUrl`,
    );
  }
});

test("every seeded employee is in a known department and has a unique email", () => {
  const db = readDb();
  const seen = new Set();

  for (const employee of db.employees) {
    assert.ok(
      db.departments.includes(employee.department),
      `${employee.email} is in unknown department ${employee.department}`,
    );
    assert.equal(seen.has(employee.email), false, `duplicate email ${employee.email}`);
    seen.add(employee.email);
  }
});

test("new ids continue from the highest number, not the list length", () => {
  // A gap in the numbering must not cause a repeated id.
  const employees = [{ id: "emp-1" }, { id: "emp-7" }];
  assert.equal(nextId("emp", employees), "emp-8");
  assert.equal(nextId("prj", []), "prj-1");
});

test("the counter stops a deleted id from being handed out again", () => {
  // emp-7 has been deleted, so only emp-1 is left — but the counter remembers.
  assert.equal(nextId("emp", [{ id: "emp-1" }], { emp: 7 }), "emp-8");
  // The counter never drags an id backwards either.
  assert.equal(nextId("emp", [{ id: "emp-9" }], { emp: 3 }), "emp-10");
});
