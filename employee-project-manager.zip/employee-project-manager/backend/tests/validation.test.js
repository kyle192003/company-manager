/**
 * Tests for the business rules.
 * LOGIC CHECK: "A project must have at least one employee."
 */

import test from "node:test";
import assert from "node:assert/strict";

import {
  validateEmployee,
  validateProject,
  getProjectWarnings,
  findProjectsLeftEmptyBy,
  isValid,
} from "../src/validation.js";
import { makeDb, TODAY, validEmployeeInput, validProjectInput } from "./helpers.js";

// --- Employees -------------------------------------------------------------

test("a complete employee passes validation", () => {
  const db = makeDb();
  const errors = validateEmployee(validEmployeeInput(), {
    employees: db.employees,
    departments: db.departments,
  });
  assert.equal(isValid(errors), true);
});

test("every required employee field is reported when the form is empty", () => {
  const db = makeDb();
  const errors = validateEmployee({}, { employees: db.employees, departments: db.departments });

  assert.deepEqual(Object.keys(errors).sort(), [
    "department",
    "email",
    "firstName",
    "lastName",
    "position",
  ]);
});

test("an email already used by another employee is rejected", () => {
  const db = makeDb();
  const errors = validateEmployee(
    // Same address as emp-1, in different capitals.
    validEmployeeInput({ email: "MARIA.SANTOS@example.com" }),
    { employees: db.employees, departments: db.departments },
  );

  assert.match(errors.email, /already uses this email/);
});

test("a malformed email is rejected", () => {
  const db = makeDb();
  const errors = validateEmployee(validEmployeeInput({ email: "grace.lim.example.com" }), {
    employees: db.employees,
    departments: db.departments,
  });

  assert.match(errors.email, /valid email/);
});

test("a department outside the allowed list is rejected", () => {
  const db = makeDb();
  const errors = validateEmployee(validEmployeeInput({ department: "Legal" }), {
    employees: db.employees,
    departments: db.departments,
  });

  assert.match(errors.department, /from the list/);
});

// --- Projects --------------------------------------------------------------

test("a complete project passes validation", () => {
  const db = makeDb();
  const errors = validateProject(validProjectInput(), { employees: db.employees });
  assert.equal(isValid(errors), true);
});

test("LOGIC CHECK: a project with no employees is rejected", () => {
  const db = makeDb();
  const errors = validateProject(validProjectInput({ employeeIds: [] }), {
    employees: db.employees,
  });

  assert.match(errors.employeeIds, /at least one employee/);
});

test("a project naming an employee who does not exist is rejected", () => {
  const db = makeDb();
  const errors = validateProject(validProjectInput({ employeeIds: ["emp-1", "emp-999"] }), {
    employees: db.employees,
  });

  assert.match(errors.employeeIds, /emp-999/);
});

test("a complexity outside low/medium/high is rejected", () => {
  const db = makeDb();
  const errors = validateProject(validProjectInput({ complexity: "urgent" }), {
    employees: db.employees,
  });

  assert.match(errors.complexity, /low, medium or high/);
});

test("a missing start date is rejected", () => {
  const db = makeDb();
  const errors = validateProject(validProjectInput({ startDate: "" }), {
    employees: db.employees,
  });

  assert.match(errors.startDate, /required/);
});

// --- Warnings --------------------------------------------------------------

test("a start date in the past produces a warning, not an error", () => {
  const db = makeDb();
  const input = validProjectInput({ startDate: "2026-01-05" });

  assert.equal(isValid(validateProject(input, { employees: db.employees })), true);

  const warnings = getProjectWarnings(input, { projects: db.projects, now: TODAY });
  assert.equal(warnings.some((warning) => /already started/.test(warning)), true);
});

test("reusing an existing project name produces a warning", () => {
  const db = makeDb();
  const warnings = getProjectWarnings(validProjectInput({ name: "customer portal redesign" }), {
    projects: db.projects,
    now: TODAY,
  });

  assert.equal(warnings.some((warning) => /already has this name/.test(warning)), true);
});

// --- Delete guard ----------------------------------------------------------

test("LOGIC CHECK: deleting the only member of a project is flagged", () => {
  const db = makeDb();
  const blocked = findProjectsLeftEmptyBy("emp-3", db.projects);

  assert.equal(blocked.length, 1);
  assert.equal(blocked[0].id, "prj-2");
});

test("deleting an employee who shares a project with others is not flagged", () => {
  const db = makeDb();
  assert.deepEqual(findProjectsLeftEmptyBy("emp-1", db.projects), []);
});
