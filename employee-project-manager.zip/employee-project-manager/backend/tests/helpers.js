/**
 * helpers.js — shared fixtures for the backend tests.
 *
 * `makeDb()` returns a small in-memory database, so tests never read or write
 * the real data/db.json. Every test gets a fresh copy.
 */

/** A tiny but realistic database: 3 employees, 2 projects. */
export function makeDb() {
  return {
    departments: ["Engineering", "Design", "Finance"],
    employees: [
      {
        id: "emp-1",
        firstName: "Maria",
        lastName: "Santos",
        email: "maria.santos@example.com",
        position: "Senior Software Engineer",
        department: "Engineering",
        hireDate: "2021-03-15",
      },
      {
        id: "emp-2",
        firstName: "Paolo",
        lastName: "Reyes",
        email: "paolo.reyes@example.com",
        position: "Product Designer",
        department: "Design",
        hireDate: "2020-11-02",
      },
      {
        id: "emp-3",
        firstName: "Bea",
        lastName: "Navarro",
        email: "bea.navarro@example.com",
        position: "Accountant",
        department: "Finance",
        hireDate: "2024-04-01",
      },
    ],
    projects: [
      {
        // Two members, so removing either one is safe.
        id: "prj-1",
        name: "Customer Portal Redesign",
        description: "Rebuild the portal.",
        employeeIds: ["emp-1", "emp-2"],
        complexity: "high",
        startDate: "2026-06-01",
      },
      {
        // One member only — deleting emp-3 must be refused.
        id: "prj-2",
        name: "Budget Dashboard",
        description: "Roll up departmental spend.",
        employeeIds: ["emp-3"],
        complexity: "medium",
        startDate: "2026-11-03",
      },
    ],
  };
}

/** A fixed "today" so tests never depend on the real clock. */
export const TODAY = "2026-09-22";

/** A valid new-employee form submission, which individual tests then break on purpose. */
export function validEmployeeInput(overrides = {}) {
  return {
    firstName: "Grace",
    lastName: "Lim",
    email: "grace.lim@example.com",
    position: "QA Engineer",
    department: "Engineering",
    hireDate: "2023-01-09",
    ...overrides,
  };
}

/** A valid new-project form submission. */
export function validProjectInput(overrides = {}) {
  return {
    name: "Internal API Gateway",
    description: "Put internal traffic behind one gateway.",
    employeeIds: ["emp-1"],
    complexity: "high",
    startDate: "2026-12-01",
    ...overrides,
  };
}
