/**
 * Tests for the employee endpoints.
 *
 * REQUIREMENTS covered: list, view details, filter by department, search by name,
 * add, delete.
 */

import test from "node:test";
import assert from "node:assert/strict";

import {
  listEmployees,
  getEmployee,
  createEmployee,
  deleteEmployee,
} from "../src/services/employee.service.js";
import { makeDb, validEmployeeInput } from "./helpers.js";

test("the list returns every employee, sorted by last name", () => {
  const { status, body } = listEmployees(makeDb(), {});

  assert.equal(status, 200);
  assert.deepEqual(body.map((employee) => employee.lastName), ["Navarro", "Reyes", "Santos"]);
});

test("REQUIREMENT: employees can be searched by name, ignoring case", () => {
  const { body } = listEmployees(makeDb(), { search: "mar" });

  assert.equal(body.length, 1);
  assert.equal(body[0].id, "emp-1");
});

test("a search matches the last name too", () => {
  const { body } = listEmployees(makeDb(), { search: "reyes" });
  assert.equal(body[0].id, "emp-2");
});

test("REQUIREMENT: employees can be filtered by department", () => {
  const { body } = listEmployees(makeDb(), { department: "Design" });

  assert.equal(body.length, 1);
  assert.equal(body[0].department, "Design");
});

test("the search and the department filter apply together", () => {
  // "a" appears in every name, but only one of them is in Finance.
  const { body } = listEmployees(makeDb(), { search: "a", department: "Finance" });

  assert.equal(body.length, 1);
  assert.equal(body[0].id, "emp-3");
});

test("REQUIREMENT: employee details include the projects they are on", () => {
  const { status, body } = getEmployee(makeDb(), "emp-1");

  assert.equal(status, 200);
  assert.equal(body.firstName, "Maria");
  assert.deepEqual(body.projects.map((project) => project.id), ["prj-1"]);
});

test("asking for an employee who does not exist returns 404", () => {
  const { status } = getEmployee(makeDb(), "emp-999");
  assert.equal(status, 404);
});

test("REQUIREMENT: an employee can be added and gets a fresh id", () => {
  const db = makeDb();
  const { status, body, nextDb } = createEmployee(db, validEmployeeInput());

  assert.equal(status, 201);
  assert.equal(body.id, "emp-4");
  assert.equal(nextDb.employees.length, 4);
  // The original database object is untouched, which is what keeps these
  // handlers safe to call from anywhere.
  assert.equal(db.employees.length, 3);
});

test("an invalid employee is refused with 400 and per-field messages", () => {
  const db = makeDb();
  const { status, body, nextDb } = createEmployee(db, validEmployeeInput({ email: "" }));

  assert.equal(status, 400);
  assert.ok(body.errors.email);
  // Nothing was saved.
  assert.equal(nextDb, undefined);
});

test("REQUIREMENT: an employee can be deleted", () => {
  const db = makeDb();
  const { status, nextDb } = deleteEmployee(db, "emp-1");

  assert.equal(status, 200);
  assert.equal(nextDb.employees.length, 2);
});

test("deleting an employee also removes them from their projects", () => {
  const { nextDb } = deleteEmployee(makeDb(), "emp-1");
  const project = nextDb.projects.find((candidate) => candidate.id === "prj-1");

  assert.deepEqual(project.employeeIds, ["emp-2"]);
});

test("LOGIC CHECK: deleting the only employee on a project is refused with 409", () => {
  const db = makeDb();
  const { status, body, nextDb } = deleteEmployee(db, "emp-3");

  assert.equal(status, 409);
  assert.match(body.message, /Budget Dashboard/);
  assert.deepEqual(body.blockingProjects, [{ id: "prj-2", name: "Budget Dashboard" }]);
  // Nothing was deleted.
  assert.equal(nextDb, undefined);
});

test("deleting an employee who does not exist returns 404", () => {
  const { status } = deleteEmployee(makeDb(), "emp-999");
  assert.equal(status, 404);
});

test("the id of a deleted employee is never handed out again", () => {
  // emp-3 is the highest id, so without the counter the next new employee would
  // silently take over their id — and their place in any old link or bookmark.
  let db = makeDb();
  db = createEmployee(db, validEmployeeInput()).nextDb; // emp-4
  db = deleteEmployee(db, "emp-4").nextDb;

  const { body } = createEmployee(db, validEmployeeInput({ email: "new.person@example.com" }));
  assert.equal(body.id, "emp-5");
});
