# Backend

Express API over a JSON file, in a layered structure. One dependency: Express.

```bash
npm install
npm start        # http://localhost:4000
npm run dev      # the same, restarting on save
npm test         # 57 unit tests
npm run reset-db # put the sample data back
```

## The layers

A request falls through these in order, and each one has a single job:

```
  HTTP request
      ↓
  routes/       which URL runs which controller function
      ↓
  controllers/  read the request, call the service, send the response
      ↓
  services/     the actual operations — decide what happens and what status
      ↓
  models/       the shape of a record, and the collection operations
      ↓
  data/db.json
```

with two supporting folders off to the side:

```
  validators/   the business rules, called by the services
  middleware/   CORS, 404 and the error handler
  utils/        dates, filtering, and the one place that saves the database
```

## Every file

| File | Job |
| --- | --- |
| `src/server.js` | Entry point. Builds the app and opens the port. Nothing else. |
| `src/app.js` | Assembles Express: middleware, routes, fallbacks — in that order. |
| `src/routes/index.js` | Mounts every router under `/api`. |
| `src/routes/employee.routes.js` | The employee URLs. |
| `src/routes/project.routes.js` | The project URLs. |
| `src/routes/meta.routes.js` | `/api/meta`, `/api/departments`, `/api/health`. |
| `src/controllers/employee.controller.js` | Request in, service call, response out. |
| `src/controllers/project.controller.js` | The same for projects. |
| `src/controllers/meta.controller.js` | The reference endpoints. |
| `src/services/employee.service.js` | List, view, add and delete an employee. |
| `src/services/project.service.js` | List, view and create a project. |
| `src/models/employee.model.js` | What an employee record is; add and remove one. |
| `src/models/project.model.js` | What a project record is; add one, attach its team. |
| `src/models/database.js` | Reads and writes `data/db.json`, and hands out ids. |
| `src/validators/employee.validator.js` | The rules a new employee must pass. |
| `src/validators/project.validator.js` | The project rules. **The logic checks live here.** |
| `src/validators/rules.js` | The small reusable checks the two are built from. |
| `src/validators/index.js` | One import point for all of the above. |
| `src/middleware/cors.middleware.js` | Lets the Vite dev server call the API. |
| `src/middleware/notFound.middleware.js` | A JSON 404 for an unknown URL. |
| `src/middleware/error.middleware.js` | Catches anything thrown, including bad JSON. |
| `src/utils/dates.js` | Whether a project has started, and how it is worded. |
| `src/utils/filters.js` | Search and department filtering. |
| `src/utils/respond.js` | Sends a service result, saving the database if it changed. |
| `data/seed.json` | The original sample data. Never written to. |
| `data/db.json` | The live database. Created from the seed if it is missing. |

## Two decisions worth explaining

**Services return data, they do not send responses.** Every service function takes
the current database and returns `{ status, body }`, plus `nextDb` when the data
changed. It never touches `req` or `res`, and never writes to disk.

That is what makes the test suite what it is: `tests/employee.service.test.js`
covers every branch of every endpoint — the 409 on a blocked delete, the 400 on a
duplicate email, the id that is never reused — by calling functions with a fake
database. No server starts, no `supertest`, no faking `req` and `res`. The whole
backend suite finishes in under a second.

**Saving happens in one place.** Because services are pure, something has to
persist the `nextDb` they return. That is `utils/respond.js`, used by every
controller. One write path, and a service that forgets to return `nextDb` simply
changes nothing rather than saving half its work.

## Ids are never reused

Deleting `emp-12` and then adding someone must not hand the new person `emp-12`.
`db.json` keeps a `counters` object with the highest number ever given out per
prefix, so an id retires with the record. See `nextId()` in `src/models/database.js`.

## Tests

`tests/` mirrors `src/`:

| Test file | Covers |
| --- | --- |
| `employee.service.test.js` | Every employee operation, including the delete guard. |
| `project.service.test.js` | Every project operation, including the started flag. |
| `validators.test.js` | The rules, including the photo URL safety check. |
| `dates.test.js` | The started / upcoming logic. |
| `database.test.js` | Reading and writing the file, and the seed data's consistency. |
| `helpers.js` | The fake database every test starts from. |
