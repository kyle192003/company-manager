# Backend

Express API over a JSON file. One dependency: Express.

```bash
npm install
npm start        # http://localhost:4000
npm run dev      # the same, restarting on save
npm test         # 53 unit tests, no install needed beyond the above
npm run reset-db # put the sample data back
```

## What each file does

| File | Job |
| --- | --- |
| `src/server.js` | The Express routes. Deliberately thin — it reads the database, calls a handler, saves the result. |
| `src/employees.js` | Every employee operation, as plain functions returning `{ status, body, nextDb? }`. |
| `src/projects.js` | The same for projects. |
| `src/validation.js` | The business rules. **The logic checks live here.** |
| `src/dates.js` | Whether a project has started, and how it is worded. |
| `src/filters.js` | Search and department filtering. |
| `src/db.js` | Reads and writes `data/db.json`, and hands out ids. |
| `data/seed.json` | The original sample data. Never written to. |
| `data/db.json` | The live database. Created from the seed if it is missing. |

## Why the handlers are not Express routes

`listEmployees(db, query)` and friends know nothing about HTTP. They take data and return
data, so:

- the tests call them directly, with a fake database and no server running;
- `server.js` stays small enough to read in one go;
- swapping the JSON file for a real database later means changing `db.js` and nothing else.

## Ids are never reused

Deleting `emp-12` and then adding someone must not hand the new person `emp-12`. `db.json`
keeps a `counters` object with the highest number ever given out per prefix, so an id
retires with the record. See `nextId()` in `src/db.js`.
