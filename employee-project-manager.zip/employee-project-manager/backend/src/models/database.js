/**
 * db.js — the "database".
 *
 * There is no SQL here: the whole dataset is one JSON file, data/db.json,
 * read into memory on each request and written back after a change.
 *
 * Two files are involved:
 *   data/seed.json — the original sample data. Never written to.
 *   data/db.json   — the live database. Created from seed.json if missing.
 *
 * Set the DB_FILE environment variable to point at a different file; the tests
 * use that to run against a throwaway copy instead of the real data.
 */

import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

// This file sits in src/models/, so the data folder is two levels up.
const thisFolder = path.dirname(fileURLToPath(import.meta.url));
const dataFolder = path.join(thisFolder, "..", "..", "data");

/** The untouched sample data used to create or reset the database. */
export const SEED_FILE = path.join(dataFolder, "seed.json");

/** The live database file. Overridable so tests never touch the real one. */
export const DB_FILE = process.env.DB_FILE || path.join(dataFolder, "db.json");

/** Reads and parses a JSON file. */
function readJson(file) {
  return JSON.parse(fs.readFileSync(file, "utf8"));
}

/**
 * Loads the whole database.
 * If db.json does not exist yet (fresh clone), it is created from seed.json,
 * so the app works straight after `npm install` with no setup step.
 */
export function readDb() {
  if (!fs.existsSync(DB_FILE)) resetDb();
  const db = readJson(DB_FILE);

  // Defensive defaults: a hand-edited file missing a key should not crash the API.
  return {
    departments: db.departments ?? [],
    employees: db.employees ?? [],
    projects: db.projects ?? [],
    // Highest id number ever handed out, per prefix. See nextId() below.
    // A file that has no counters yet (a fresh copy of seed.json) gets them
    // derived from the records it already holds.
    counters: db.counters ?? deriveCounters(db),
  };
}

/** Reads the highest id number already present, per prefix: { emp: 12, prj: 8 }. */
function deriveCounters(db) {
  return {
    emp: (db.employees ?? []).reduce((max, item) => Math.max(max, idNumber(item.id)), 0),
    prj: (db.projects ?? []).reduce((max, item) => Math.max(max, idNumber(item.id)), 0),
  };
}

/**
 * Saves the whole database.
 * Writes to a temporary file first and then renames it, so an interrupted write
 * can never leave a half-written db.json behind.
 */
export function writeDb(db) {
  const temporaryFile = `${DB_FILE}.tmp`;
  fs.mkdirSync(path.dirname(DB_FILE), { recursive: true });
  fs.writeFileSync(temporaryFile, `${JSON.stringify(db, null, 2)}\n`, "utf8");
  fs.renameSync(temporaryFile, DB_FILE);
  return db;
}

/** Copies seed.json over db.json, throwing away any changes. Used by `npm run reset-db`. */
export function resetDb() {
  return writeDb(readJson(SEED_FILE));
}

/** Pulls the number out of an id: "emp-13" → 13. Returns 0 if there isn't one. */
export function idNumber(id) {
  const match = String(id ?? "").match(/(\d+)$/);
  return match ? Number(match[1]) : 0;
}

/**
 * Builds the next id for a list, e.g. "emp-13" or "prj-9".
 *
 * WHY the counters argument: counting the list, or even taking the highest id
 * still in it, would recycle the id of a deleted record — delete emp-12 and the
 * next new employee would become emp-12 again, silently inheriting their
 * identity. `counters` remembers the highest number ever handed out for a
 * prefix, so an id is never reused. It is stored in db.json alongside the data.
 */
export function nextId(prefix, items = [], counters = {}) {
  const highestInUse = items.reduce((max, item) => Math.max(max, idNumber(item.id)), 0);
  const highestEverUsed = Number(counters[prefix] ?? 0);
  return `${prefix}-${Math.max(highestInUse, highestEverUsed) + 1}`;
}

/** Records that an id has been handed out, so it can never be reused. */
export function rememberId(counters = {}, prefix, id) {
  return { ...counters, [prefix]: Math.max(Number(counters[prefix] ?? 0), idNumber(id)) };
}
