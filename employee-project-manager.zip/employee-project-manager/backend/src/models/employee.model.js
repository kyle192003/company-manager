/**
 * employee.model.js — the shape of an employee, and the operations on the
 * employee collection.
 *
 * This is the layer that knows what an employee record looks like. It does not
 * validate (that is validators/) and it does not decide HTTP status codes
 * (that is services/). It also never writes to disk — every function takes the
 * database and returns a new one, leaving the original untouched, and the
 * controller saves the result.
 */

import { nextId, rememberId } from "./database.js";

/** The prefix every employee id carries: emp-1, emp-2, … */
export const ID_PREFIX = "emp";

/** One employee from the collection, or undefined. */
export function findById(db, id) {
  return db.employees.find((employee) => employee.id === id);
}

/** Every project this employee is assigned to. */
export function findProjects(db, employeeId) {
  return db.projects.filter((project) => project.employeeIds.includes(employeeId));
}

/**
 * Builds a new employee record from submitted form values.
 * Assumes the values have already passed validateEmployee().
 */
export function build(db, payload) {
  return {
    id: nextId(ID_PREFIX, db.employees, db.counters),
    firstName: payload.firstName.trim(),
    lastName: payload.lastName.trim(),
    email: payload.email.trim(),
    position: payload.position.trim(),
    department: payload.department.trim(),
    // Hire date is optional; default to today so the record is never half-empty.
    hireDate: payload.hireDate?.trim() || new Date().toISOString().slice(0, 10),
    // Photo is optional. Empty means the UI falls back to their initials.
    photoUrl: payload.photoUrl?.trim() || "",
  };
}

/** Returns a new database with this employee added. */
export function add(db, employee) {
  return {
    ...db,
    employees: [...db.employees, employee],
    // Remember the number so this id is never handed out again, even after a delete.
    counters: rememberId(db.counters, ID_PREFIX, employee.id),
  };
}

/**
 * Returns a new database with this employee gone.
 *
 * Also strips them from every project they were on. The caller is responsible
 * for checking findProjectsLeftEmptyBy() first — this function does not enforce
 * the "at least one employee" rule, it just performs the removal.
 */
export function remove(db, id) {
  return {
    ...db,
    // Remember the id we are retiring, so a future employee can never inherit it.
    counters: rememberId(db.counters, ID_PREFIX, id),
    employees: db.employees.filter((employee) => employee.id !== id),
    projects: db.projects.map((project) => ({
      ...project,
      employeeIds: project.employeeIds.filter((memberId) => memberId !== id),
    })),
  };
}
