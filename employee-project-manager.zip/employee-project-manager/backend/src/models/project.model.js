/**
 * project.model.js — the shape of a project, and the operations on the
 * project collection.
 *
 * Same rules as employee.model.js: no validation, no HTTP, no writing to disk.
 * Every function takes the database and returns a new one.
 */

import { nextId, rememberId } from "./database.js";
import { hasStarted } from "../utils/dates.js";

/** The prefix every project id carries: prj-1, prj-2, … */
export const ID_PREFIX = "prj";

/** One project from the collection, or undefined. */
export function findById(db, id) {
  return db.projects.find((project) => project.id === id);
}

/**
 * Builds a new project record from submitted form values.
 * Assumes the values have already passed validateProject().
 */
export function build(db, payload) {
  return {
    id: nextId(ID_PREFIX, db.projects, db.counters),
    name: payload.name.trim(),
    description: payload.description.trim(),
    // Remove any duplicate ids that a client might send.
    employeeIds: [...new Set(payload.employeeIds)],
    complexity: payload.complexity.trim(),
    startDate: payload.startDate.trim(),
  };
}

/** Returns a new database with this project added. */
export function add(db, project) {
  return {
    ...db,
    projects: [...db.projects, project],
    // Remember the number so this id is never handed out again.
    counters: rememberId(db.counters, ID_PREFIX, project.id),
  };
}

/**
 * Swaps the employee ids for the full employee records, and works out whether
 * the project has started.
 *
 * The UI needs names rather than ids, and the started flag saves every client
 * from repeating the date rule.
 *
 * LOGIC CHECK: hasStarted is what the "already started" indicator reads.
 */
export function withEmployees(project, employees, now) {
  return {
    ...project,
    employees: project.employeeIds
      .map((id) => employees.find((employee) => employee.id === id))
      .filter(Boolean),
    hasStarted: hasStarted(project.startDate, now),
  };
}
