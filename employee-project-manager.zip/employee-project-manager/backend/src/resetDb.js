/**
 * resetDb.js — throws away every change and restores the sample data.
 * Run it with `npm run reset-db` from the backend folder.
 */

import { resetDb, DB_FILE } from "./db.js";

resetDb();
console.log(`Database reset from seed.json → ${DB_FILE}`);
