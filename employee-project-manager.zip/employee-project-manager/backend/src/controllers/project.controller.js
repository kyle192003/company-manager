/**
 * project.controller.js — the HTTP layer for projects.
 *
 * As thin as the employee controller. The only extra is `today()`, passed in so
 * the service never reads the clock itself — which is what lets the tests pin a
 * fixed date and check the started/upcoming rule reliably.
 */

import { readDb } from "../models/database.js";
import { today } from "../utils/dates.js";
import { sendResult } from "../utils/respond.js";
import * as projectService from "../services/project.service.js";

/** GET /api/projects?search= */
export function index(req, res) {
  sendResult(res, projectService.listProjects(readDb(), req.query, today()));
}

/** GET /api/projects/:id */
export function show(req, res) {
  sendResult(res, projectService.getProject(readDb(), req.params.id, today()));
}

/** POST /api/projects */
export function create(req, res) {
  sendResult(res, projectService.createProject(readDb(), req.body, today()));
}
