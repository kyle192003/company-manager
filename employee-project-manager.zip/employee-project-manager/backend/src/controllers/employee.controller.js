/**
 * employee.controller.js — the HTTP layer for employees.
 *
 * Each function does the same three things and nothing else:
 *   1. pull what it needs off the request,
 *   2. hand it to the service along with the current database,
 *   3. send the result back.
 *
 * All the decisions — what is valid, what status code, what message — belong to
 * the service. Keeping the controller this thin is why the service tests cover
 * the real behaviour rather than a stand-in for it.
 */

import { readDb } from "../models/database.js";
import { sendResult } from "../utils/respond.js";
import * as employeeService from "../services/employee.service.js";

/** GET /api/employees?search=&department= */
export function index(req, res) {
  sendResult(res, employeeService.listEmployees(readDb(), req.query));
}

/** GET /api/employees/:id */
export function show(req, res) {
  sendResult(res, employeeService.getEmployee(readDb(), req.params.id));
}

/** POST /api/employees */
export function create(req, res) {
  sendResult(res, employeeService.createEmployee(readDb(), req.body));
}

/** DELETE /api/employees/:id */
export function destroy(req, res) {
  sendResult(res, employeeService.deleteEmployee(readDb(), req.params.id));
}
