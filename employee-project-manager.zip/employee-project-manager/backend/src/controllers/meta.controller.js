/**
 * meta.controller.js — the small reference endpoints.
 *
 * These have no service of their own because there is no decision to make:
 * they read a value and send it. Inventing a meta.service.js to wrap a single
 * property read would be a layer that carries nothing.
 */

import { readDb } from "../models/database.js";
import { today } from "../utils/dates.js";
import { COMPLEXITY_LEVELS } from "../validators/project.validator.js";

/** GET /api/departments — fills the department filter and the dropdown. */
export function departments(req, res) {
  res.json(readDb().departments);
}

/**
 * GET /api/meta — the small values the UI needs, so they are defined once on
 * the server rather than hard-coded in the browser.
 */
export function meta(req, res) {
  const db = readDb();

  res.json({
    departments: db.departments,
    complexityLevels: COMPLEXITY_LEVELS,
    today: today(),
  });
}

/** GET /api/health — lets the UI tell "API is down" from "no results". */
export function health(req, res) {
  res.json({ ok: true, today: today() });
}
