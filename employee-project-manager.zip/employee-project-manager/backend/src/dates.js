/**
 * dates.js — every date rule in the app lives here.
 *
 * LOGIC CHECK: "UI must indicate if a project has already started based on the
 * start date." `describeStart()` below is the single place that decides that.
 *
 * WHY strings instead of Date objects: dates here are calendar days
 * ("2026-10-05"), not moments in time. Comparing the strings avoids every
 * timezone bug, because "2026-10-05" <= "2026-10-19" is already true
 * alphabetically for the YYYY-MM-DD format.
 */

/** Turns a Date into a "YYYY-MM-DD" string using the local calendar day. */
export function toDateString(date) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

/** Today as "YYYY-MM-DD". Kept separate so tests can pass a fixed day instead. */
export function today() {
  return toDateString(new Date());
}

/**
 * True only for a real calendar day in "YYYY-MM-DD" form.
 * Rejects nonsense like "2026-02-30", which `new Date()` would silently
 * roll over into March.
 */
export function isValidDateString(value) {
  if (typeof value !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const [year, month, day] = value.split("-").map(Number);
  const parsed = new Date(Date.UTC(year, month - 1, day));
  return (
    parsed.getUTCFullYear() === year &&
    parsed.getUTCMonth() === month - 1 &&
    parsed.getUTCDate() === day
  );
}

/** Whole days from one calendar day to another. Negative if `to` is earlier. */
export function daysBetween(from, to) {
  const start = Date.parse(`${from}T00:00:00Z`);
  const end = Date.parse(`${to}T00:00:00Z`);
  return Math.round((end - start) / 86_400_000);
}

/**
 * A project counts as started when its start date is today or earlier.
 * `now` is a parameter so tests can pin "today" instead of depending on the clock.
 */
export function hasStarted(startDate, now = today()) {
  if (!isValidDateString(startDate)) return false;
  return startDate <= now;
}

/**
 * The status the UI shows on a project: whether it has started, and a label.
 * Returns e.g. { started: true, days: 12, label: "Started 12 days ago" }
 */
export function describeStart(startDate, now = today()) {
  if (!isValidDateString(startDate)) {
    return { started: false, days: null, label: "No start date" };
  }

  if (hasStarted(startDate, now)) {
    const days = daysBetween(startDate, now);
    return {
      started: true,
      days,
      label: days === 0 ? "Starts today" : `Started ${days} ${plural(days, "day")} ago`,
    };
  }

  const days = daysBetween(now, startDate);
  return { started: false, days, label: `Starts in ${days} ${plural(days, "day")}` };
}

/** "1 day" vs "3 days". */
function plural(count, word) {
  return count === 1 ? word : `${word}s`;
}
