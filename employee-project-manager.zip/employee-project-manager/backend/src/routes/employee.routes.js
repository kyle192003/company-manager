/**
 * employee.routes.js — which URL runs which controller function.
 *
 * Nothing else. Reading this file should tell you the whole employee API at a
 * glance.
 */

import { Router } from "express";

import * as employeeController from "../controllers/employee.controller.js";

const router = Router();

// REQUIREMENT: display a comprehensive list of employees, searchable by name
// and filterable by department.
router.get("/", employeeController.index);

// REQUIREMENT: view individual employee details.
router.get("/:id", employeeController.show);

// REQUIREMENT: add an employee.
router.post("/", employeeController.create);

// REQUIREMENT: delete an employee.
router.delete("/:id", employeeController.destroy);

export default router;
