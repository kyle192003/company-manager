/**
 * project.routes.js — which URL runs which controller function, for projects.
 */

import { Router } from "express";

import * as projectController from "../controllers/project.controller.js";

const router = Router();

// REQUIREMENT: list projects, searchable by name.
router.get("/", projectController.index);

router.get("/:id", projectController.show);

// REQUIREMENT: create a new project.
router.post("/", projectController.create);

export default router;
