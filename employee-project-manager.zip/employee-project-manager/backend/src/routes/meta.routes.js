/**
 * meta.routes.js — the reference and health endpoints.
 */

import { Router } from "express";

import * as metaController from "../controllers/meta.controller.js";

const router = Router();

router.get("/departments", metaController.departments);
router.get("/meta", metaController.meta);
router.get("/health", metaController.health);

export default router;
