/**
 * routes/index.js — mounts every router under /api.
 *
 * One place to see the whole API surface:
 *   /api/employees/*  → employee.routes.js
 *   /api/projects/*   → project.routes.js
 *   /api/departments, /api/meta, /api/health → meta.routes.js
 */

import { Router } from "express";

import employeeRoutes from "./employee.routes.js";
import projectRoutes from "./project.routes.js";
import metaRoutes from "./meta.routes.js";

const router = Router();

router.use("/employees", employeeRoutes);
router.use("/projects", projectRoutes);
// Mounted at the root of /api, because these are single endpoints rather than
// a collection with its own path.
router.use("/", metaRoutes);

export default router;
