/**
 * employees.js — everything the API can do with employees.
 *
 * REQUIREMENTS covered here:
 *   - Display a comprehensive list of employees
 *   - View individual employee details
 *   - Filter employees by department
 *   - Search employees by name
 *   - Add an employee
 *   - Delete an employee
 *
 * These are plain functions, not Express routes. Each takes the current database
 * and returns { status, body } — plus `nextDb` when the data changed.
 *
 * WHY this shape: nothing here imports Express, so the tests call these functions
 * directly with a fake database. server.js is left as a thin wiring layer, which
 * means almost the whole backend is covered by fast, dependency-free tests.
 */

import { nextId, rememberId } from "./db.js";
import { filterEmployees, sortEmployees, ALL_DEPARTMENTS } from "./filters.js";
import { validateEmployee, findProjectsLeftEmptyBy, isValid } from "./validation.js";

/**
 * GET /api/employees
 * Optional query: ?search=mar&department=Engineering
 */
export function listEmployees(db, query = {}) {
  const matching = filterEmployees(db.employees, {
    search: query.search ?? "",
    department: query.department ?? ALL_DEPARTMENTS,
  });

  return { status: 200, body: sortEmployees(matching) };
}

/**
 * GET /api/employees/:id
 * Returns the employee together with the projects they are assigned to, which is
 * what the details view shows.
 */
export function getEmployee(db, id) {
  const employee = db.employees.find((candidate) => candidate.id === id);
  if (!employee) {
    return { status: 404, body: { message: `No employee with id "${id}".` } };
  }

  const projects = db.projects.filter((project) => project.employeeIds.includes(id));
  return { status: 200, body: { ...employee, projects } };
}

/**
 * POST /api/employees
 * Rejects the request with 400 and a per-field error map when the rules fail.
 */
export function createEmployee(db, payload = {}) {
  const errors = validateEmployee(payload, {
    employees: db.employees,
    departments: db.departments,
  });

  if (!isValid(errors)) {
    return { status: 400, body: { message: "Please fix the highlighted fields.", errors } };
  }

  const employee = {
    id: nextId("emp", db.employees, db.counters),
    firstName: payload.firstName.trim(),
    lastName: payload.lastName.trim(),
    email: payload.email.trim(),
    position: payload.position.trim(),
    department: payload.department.trim(),
    // Hire date is optional; default to today so the record is never half-empty.
    hireDate: payload.hireDate?.trim() || new Date().toISOString().slice(0, 10),
  };

  return {
    status: 201,
    body: employee,
    nextDb: {
      ...db,
      employees: [...db.employees, employee],
      // Remember the number so this id is never handed out again, even after a delete.
      counters: rememberId(db.counters, "emp", employee.id),
    },
  };
}

/**
 * DELETE /api/employees/:id
 *
 * LOGIC CHECK: a project must always keep at least one employee, so deleting
 * someone who is the only member of a project is refused with 409 and a message
 * naming those projects. Otherwise the employee is removed from the directory
 * and from every project they were on.
 */
export function deleteEmployee(db, id) {
  const employee = db.employees.find((candidate) => candidate.id === id);
  if (!employee) {
    return { status: 404, body: { message: `No employee with id "${id}".` } };
  }

  const wouldEmpty = findProjectsLeftEmptyBy(id, db.projects);
  if (wouldEmpty.length > 0) {
    const names = wouldEmpty.map((project) => `"${project.name}"`).join(", ");
    return {
      status: 409,
      body: {
        message:
          `${employee.firstName} ${employee.lastName} is the only employee on ${names}. ` +
          "Add someone else to those projects first, because a project must have at least one employee.",
        blockingProjects: wouldEmpty.map(({ id: projectId, name }) => ({ id: projectId, name })),
      },
    };
  }

  const nextDb = {
    ...db,
    // Remember the id we are retiring, so a future employee can never inherit it.
    counters: rememberId(db.counters, "emp", id),
    employees: db.employees.filter((candidate) => candidate.id !== id),
    // Also take them off any project they shared with other people.
    projects: db.projects.map((project) => ({
      ...project,
      employeeIds: project.employeeIds.filter((memberId) => memberId !== id),
    })),
  };

  return { status: 200, body: { message: "Employee deleted.", id }, nextDb };
}
