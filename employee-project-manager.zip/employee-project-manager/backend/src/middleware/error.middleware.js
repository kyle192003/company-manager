/**
 * error.middleware.js — the last line of defence.
 *
 * Express recognises this as an error handler by its four arguments, and calls
 * it when any route throws. `next` is unused but must stay in the signature,
 * or Express treats this as an ordinary middleware.
 */

export function errorHandler(error, req, res, next) {
  // By far the most common case: the request body was not valid JSON.
  if (error?.type === "entity.parse.failed") {
    return res.status(400).json({ message: "The request body was not valid JSON." });
  }

  // Anything else is a bug. Log it for whoever is running the server, but do
  // not send the details to the client.
  console.error(error);
  res.status(500).json({ message: "Something went wrong on the server." });
}
