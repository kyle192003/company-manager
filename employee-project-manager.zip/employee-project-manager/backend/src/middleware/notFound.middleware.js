/**
 * notFound.middleware.js — anything no route matched.
 *
 * Runs after every router, so reaching it means the URL was a typo. Answering
 * with JSON rather than Express's default HTML keeps the client's error
 * handling uniform: every failure it sees has a `message`.
 */

export function notFound(req, res) {
  res.status(404).json({ message: `No route for ${req.method} ${req.originalUrl}.` });
}
