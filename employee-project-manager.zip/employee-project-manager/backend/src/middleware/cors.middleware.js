/**
 * cors.middleware.js — lets the browser at the Vite dev server (a different
 * port) call this API.
 *
 * Written by hand rather than pulling in the `cors` package, since the rule is
 * only a few headers and it keeps the dependency list to Express alone.
 */

export function cors(req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Methods", "GET, POST, DELETE, OPTIONS");
  res.header("Access-Control-Allow-Headers", "Content-Type");

  // A browser sends OPTIONS first to ask permission; answer it and stop there.
  if (req.method === "OPTIONS") return res.sendStatus(204);

  next();
}
