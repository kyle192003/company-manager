/**
 * project.validator.js — the rules a project must satisfy.
 *
 * LOGIC CHECK: "A project must have at least one employee."
 * That rule is enforced in two directions and both live here:
 *   - validateProject()        stops a project being created without one
 *   - findProjectsLeftEmptyBy() stops an employee being deleted if it would
 *                               leave a project with nobody on it
 *
 * The second is called from the employee service, because the rule belongs to
 * projects wherever it happens to be triggered from.
 */

import { isValidDateString, hasStarted } from "../utils/dates.js";
import { text } from "./rules.js";

/** The only complexity values a project may have. */
export const COMPLEXITY_LEVELS = ["low", "medium", "high"];

/**
 * Checks a new project.
 *
 * @param input     the submitted form values
 * @param employees employees that exist, so the chosen ones can be confirmed real
 */
export function validateProject(input = {}, { employees = [] } = {}) {
  const errors = {};

  if (!text(input.name)) errors.name = "Project name is required.";
  if (!text(input.description)) errors.description = "Description is required.";

  // LOGIC CHECK: a project must include at least one existing employee.
  const employeeIds = Array.isArray(input.employeeIds) ? input.employeeIds : [];
  if (employeeIds.length === 0) {
    errors.employeeIds = "Assign at least one employee to this project.";
  } else {
    const knownIds = new Set(employees.map((employee) => employee.id));
    const unknown = employeeIds.filter((id) => !knownIds.has(id));
    if (unknown.length > 0) {
      errors.employeeIds = `These employees no longer exist: ${unknown.join(", ")}.`;
    }
  }

  // Complexity is a fixed choice, so anything else is a mistake.
  if (!COMPLEXITY_LEVELS.includes(text(input.complexity))) {
    errors.complexity = "Choose a complexity of low, medium or high.";
  }

  const startDate = text(input.startDate);
  if (!startDate) {
    errors.startDate = "Start date is required.";
  } else if (!isValidDateString(startDate)) {
    errors.startDate = "Enter a valid start date.";
  }

  return errors;
}

/**
 * Things worth telling the user about, that are not mistakes.
 * LOGIC CHECK: the "error messages/warnings" requirement — this is the warnings half.
 */
export function getProjectWarnings(input = {}, { projects = [], now } = {}) {
  const warnings = [];
  const startDate = text(input.startDate);

  // Backdating is allowed (you may be recording a project already underway),
  // but it is worth flagging because the project will appear as already started.
  if (isValidDateString(startDate) && hasStarted(startDate, now)) {
    warnings.push(
      "This start date is today or in the past, so the project will show as already started.",
    );
  }

  // A duplicate name is not fatal, but it usually means a double submission.
  const name = text(input.name).toLowerCase();
  if (name && projects.some((project) => text(project.name).toLowerCase() === name)) {
    warnings.push("Another project already has this name.");
  }

  return warnings;
}

/**
 * LOGIC CHECK: deleting an employee must never leave a project with no employees.
 * Returns the projects that would be emptied by removing this employee — an
 * empty array means the delete is safe.
 */
export function findProjectsLeftEmptyBy(employeeId, projects = []) {
  return projects.filter((project) => {
    const members = Array.isArray(project.employeeIds) ? project.employeeIds : [];
    if (!members.includes(employeeId)) return false;
    const remaining = members.filter((id) => id !== employeeId);
    return remaining.length === 0;
  });
}
