/**
 * employee.validator.js — the rules a new employee must satisfy.
 *
 * Returns {} when the data is fine, or { field: "message" } when it is not, so
 * the UI can put each message against the input it belongs to.
 *
 * These are plain functions with no knowledge of HTTP or of the database file,
 * which is what makes them straightforward to unit test.
 */

import { isValidDateString } from "../utils/dates.js";
import { text, isValidEmail, isValidPhotoUrl } from "./rules.js";

/**
 * Checks a new employee.
 *
 * @param input       the submitted form values
 * @param employees   employees that already exist, for the duplicate email check
 * @param departments the allowed department names
 */
export function validateEmployee(input = {}, { employees = [], departments = [] } = {}) {
  const errors = {};

  if (!text(input.firstName)) errors.firstName = "First name is required.";
  if (!text(input.lastName)) errors.lastName = "Last name is required.";
  if (!text(input.position)) errors.position = "Position is required.";

  // Email: required, well formed, and not already used by someone else.
  const email = text(input.email).toLowerCase();
  if (!email) {
    errors.email = "Email is required.";
  } else if (!isValidEmail(email)) {
    errors.email = "Enter a valid email address.";
  } else if (employees.some((employee) => text(employee.email).toLowerCase() === email)) {
    errors.email = "Another employee already uses this email.";
  }

  // Department must be one we actually offer, not free text.
  const department = text(input.department);
  if (!department) {
    errors.department = "Department is required.";
  } else if (departments.length > 0 && !departments.includes(department)) {
    errors.department = "Choose a department from the list.";
  }

  // Hire date is optional, but must be a real date when given.
  const hireDate = text(input.hireDate);
  if (hireDate && !isValidDateString(hireDate)) {
    errors.hireDate = "Enter a valid date.";
  }

  // Photo is optional. Without one the UI shows the employee's initials.
  if (!isValidPhotoUrl(input.photoUrl)) {
    errors.photoUrl = "Enter a web address starting with http:// or https://.";
  }

  return errors;
}
