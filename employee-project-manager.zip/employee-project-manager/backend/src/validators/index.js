/**
 * validators/index.js — one import point for every rule.
 *
 * Lets the rest of the app write
 *   import { validateEmployee, validateProject } from "../validators/index.js";
 * instead of reaching into each file. The individual files are still there to
 * import directly when only one is needed.
 */

export { text, isValid, isValidEmail, isValidPhotoUrl } from "./rules.js";
export { validateEmployee } from "./employee.validator.js";
export {
  COMPLEXITY_LEVELS,
  validateProject,
  getProjectWarnings,
  findProjectsLeftEmptyBy,
} from "./project.validator.js";
