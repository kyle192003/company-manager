/**
 * rules.js — the small checks the entity validators are built from.
 *
 * Nothing here knows about employees or projects; these are the reusable
 * pieces. The entity rules live in employee.validator.js and
 * project.validator.js.
 */

/** Trims a value into a string, so undefined/null/numbers never crash a check. */
export function text(value) {
  return typeof value === "string" ? value.trim() : "";
}

/** True when a validator returned no problems. */
export function isValid(errors) {
  return Object.keys(errors).length === 0;
}

/** A deliberately forgiving email check: something@something.tld */
export function isValidEmail(value) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(text(value));
}

/**
 * A photo must be an ordinary web address or a path inside the app.
 *
 * WHY this is stricter than it looks: the value ends up in an <img src>, so a
 * "javascript:" or "data:" value would be a way to get code or arbitrary content
 * into the page. Allowing only http, https and relative paths shuts that off.
 */
export function isValidPhotoUrl(value) {
  const photoUrl = text(value);
  if (photoUrl === "") return true; // optional

  if (/^https?:\/\/\S+$/i.test(photoUrl)) return true;

  // A relative path: no scheme at all, and no protocol-relative "//host" form.
  return !photoUrl.includes(":") && !photoUrl.startsWith("//");
}
