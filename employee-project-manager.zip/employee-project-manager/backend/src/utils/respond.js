/**
 * respond.js — turns a service result into an HTTP response.
 *
 * Services are deliberately pure: they never write to disk. Instead they hand
 * back a `nextDb` when the data changed, and this is the one place that saves
 * it. Keeping the write here means every controller persists the same way, and
 * a service that forgot to return `nextDb` simply changes nothing rather than
 * half-saving.
 */

import { writeDb } from "../models/database.js";

/**
 * Sends a { status, body } result, saving the database first when the service
 * produced a new version of it.
 */
export function sendResult(res, result) {
  if (result.nextDb) writeDb(result.nextDb);
  res.status(result.status).json(result.body);
}
