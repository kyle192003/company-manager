/**
 * server.js — the Express layer.
 *
 * This file deliberately contains almost no logic. Its whole job is:
 *   1. receive an HTTP request,
 *   2. read the database,
 *   3. hand both to one of the plain functions in employees.js / projects.js,
 *   4. save the result if the data changed, and send the response.
 *
 * All the real behaviour lives in those modules and in validation.js, which is
 * why the tests can cover it without ever starting a server.
 */

import express from "express";

import { readDb, writeDb } from "./db.js";
import { today } from "./dates.js";
import { COMPLEXITY_LEVELS } from "./validation.js";
import { listEmployees, getEmployee, createEmployee, deleteEmployee } from "./employees.js";
import { listProjects, getProject, createProject } from "./projects.js";

const app = express();
const PORT = process.env.PORT || 4000;

/** Parses JSON request bodies into req.body. */
app.use(express.json());

/**
 * Allow the browser at the Vite dev server (a different port) to call this API.
 * Written by hand rather than pulling in the `cors` package, since the rule is
 * only a few headers and this keeps the dependency list to just Express.
 */
app.use((req, res, next) => {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Methods", "GET, POST, DELETE, OPTIONS");
  res.header("Access-Control-Allow-Headers", "Content-Type");
  // A browser sends OPTIONS first to ask permission; answer it and stop there.
  if (req.method === "OPTIONS") return res.sendStatus(204);
  next();
});

/**
 * Sends a { status, body } result, and saves the database first when the
 * handler produced a new version of it.
 */
function send(res, result) {
  if (result.nextDb) writeDb(result.nextDb);
  res.status(result.status).json(result.body);
}

// --- Employees -------------------------------------------------------------

/** GET /api/employees?search=&department= — the directory list. */
app.get("/api/employees", (req, res) => {
  send(res, listEmployees(readDb(), req.query));
});

/** GET /api/employees/:id — one employee plus their projects. */
app.get("/api/employees/:id", (req, res) => {
  send(res, getEmployee(readDb(), req.params.id));
});

/** POST /api/employees — add an employee. */
app.post("/api/employees", (req, res) => {
  send(res, createEmployee(readDb(), req.body));
});

/** DELETE /api/employees/:id — remove an employee, unless it would empty a project. */
app.delete("/api/employees/:id", (req, res) => {
  send(res, deleteEmployee(readDb(), req.params.id));
});

// --- Projects --------------------------------------------------------------

/** GET /api/projects?search= — the project list. */
app.get("/api/projects", (req, res) => {
  send(res, listProjects(readDb(), req.query, today()));
});

/** GET /api/projects/:id — one project. */
app.get("/api/projects/:id", (req, res) => {
  send(res, getProject(readDb(), req.params.id, today()));
});

/** POST /api/projects — create a project. */
app.post("/api/projects", (req, res) => {
  send(res, createProject(readDb(), req.body, today()));
});

// --- Reference data --------------------------------------------------------

/** GET /api/departments — the list that fills the department filter and dropdown. */
app.get("/api/departments", (req, res) => {
  res.json(readDb().departments);
});

/** GET /api/meta — small values the UI needs, so they are defined in one place only. */
app.get("/api/meta", (req, res) => {
  const db = readDb();
  res.json({
    departments: db.departments,
    complexityLevels: COMPLEXITY_LEVELS,
    today: today(),
  });
});

/** GET /api/health — used by the UI to tell "API is down" from "no results". */
app.get("/api/health", (req, res) => {
  res.json({ ok: true, today: today() });
});

// --- Fallbacks -------------------------------------------------------------

/** Anything else under /api is a typo in the URL. */
app.use((req, res) => {
  res.status(404).json({ message: `No route for ${req.method} ${req.originalUrl}.` });
});

/**
 * Last-resort error handler. Express calls this when a handler throws — most
 * often because the request body was not valid JSON.
 */
app.use((error, req, res, next) => {
  if (error?.type === "entity.parse.failed") {
    return res.status(400).json({ message: "The request body was not valid JSON." });
  }
  console.error(error);
  res.status(500).json({ message: "Something went wrong on the server." });
});

app.listen(PORT, () => {
  console.log(`API ready on http://localhost:${PORT}`);
});

export default app;
