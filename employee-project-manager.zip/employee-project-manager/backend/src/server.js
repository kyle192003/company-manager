/**
 * server.js — the entry point. `npm start` runs this.
 *
 * Its only job is to build the app and open a port. Everything else lives in
 * app.js and the layers below it.
 */

import { createApp } from "./app.js";

const PORT = process.env.PORT || 4000;

createApp().listen(PORT, () => {
  console.log(`API ready on http://localhost:${PORT}`);
});
