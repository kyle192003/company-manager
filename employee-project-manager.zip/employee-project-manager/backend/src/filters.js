/**
 * filters.js — searching and filtering lists.
 *
 * REQUIREMENT: "Search Employees by Name", "Filter employees by department",
 * "Search Projects by Name".
 *
 * These are pure functions over arrays: give them a list, get a new list back.
 * Nothing here touches the database or HTTP, so the unit tests are simple.
 */

/** The department value meaning "do not filter at all". */
export const ALL_DEPARTMENTS = "All";

/** Lower-cased, trimmed text — used so searches ignore case and stray spaces. */
function normalise(value) {
  return typeof value === "string" ? value.trim().toLowerCase() : "";
}

/** "Maria" + "Santos" → "maria santos", the text a name search runs against. */
export function fullName(employee) {
  return `${employee.firstName ?? ""} ${employee.lastName ?? ""}`.trim();
}

/**
 * Applies the name search and the department filter together.
 * An empty search or a department of "All" simply skips that step.
 */
export function filterEmployees(employees = [], { search = "", department = ALL_DEPARTMENTS } = {}) {
  const term = normalise(search);
  const wantedDepartment = department ?? ALL_DEPARTMENTS;

  return employees.filter((employee) => {
    // Partial, case-insensitive match anywhere in the full name.
    const matchesName = term === "" || normalise(fullName(employee)).includes(term);
    const matchesDepartment =
      wantedDepartment === ALL_DEPARTMENTS || employee.department === wantedDepartment;
    return matchesName && matchesDepartment;
  });
}

/** Same idea for projects, which are searched by project name only. */
export function filterProjects(projects = [], { search = "" } = {}) {
  const term = normalise(search);
  if (term === "") return [...projects];
  return projects.filter((project) => normalise(project.name).includes(term));
}

/** Alphabetical by last name, then first name — the order the directory shows. */
export function sortEmployees(employees = []) {
  return [...employees].sort((a, b) => {
    const byLastName = (a.lastName ?? "").localeCompare(b.lastName ?? "");
    return byLastName !== 0 ? byLastName : (a.firstName ?? "").localeCompare(b.firstName ?? "");
  });
}

/** Projects newest-start-date first, so upcoming work sits at the top. */
export function sortProjects(projects = []) {
  return [...projects].sort((a, b) => (b.startDate ?? "").localeCompare(a.startDate ?? ""));
}
