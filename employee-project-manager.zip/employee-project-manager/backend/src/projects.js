/**
 * projects.js — everything the API can do with projects.
 *
 * REQUIREMENTS covered here:
 *   - Create new projects with name, description, employees, complexity, start date
 *   - Search projects by name
 *
 * Same shape as employees.js: plain functions returning { status, body, nextDb? }.
 */

import { nextId, rememberId } from "./db.js";
import { filterProjects, sortProjects } from "./filters.js";
import { hasStarted } from "./dates.js";
import { validateProject, getProjectWarnings, isValid } from "./validation.js";

/**
 * Attaches the full employee records to a project, plus whether it has started.
 * The UI needs names, not ids, and the started flag saves the client from
 * repeating the date rule.
 */
function withDetails(project, employees, now) {
  return {
    ...project,
    employees: project.employeeIds
      .map((id) => employees.find((employee) => employee.id === id))
      .filter(Boolean),
    // LOGIC CHECK: has this project already started?
    hasStarted: hasStarted(project.startDate, now),
  };
}

/**
 * GET /api/projects
 * Optional query: ?search=portal
 */
export function listProjects(db, query = {}, now) {
  const matching = filterProjects(db.projects, { search: query.search ?? "" });
  const detailed = sortProjects(matching).map((project) =>
    withDetails(project, db.employees, now),
  );

  return { status: 200, body: detailed };
}

/** GET /api/projects/:id */
export function getProject(db, id, now) {
  const project = db.projects.find((candidate) => candidate.id === id);
  if (!project) {
    return { status: 404, body: { message: `No project with id "${id}".` } };
  }
  return { status: 200, body: withDetails(project, db.employees, now) };
}

/**
 * POST /api/projects
 *
 * LOGIC CHECK: the project must include at least one employee, and each chosen
 * employee must actually exist. Both are enforced by validateProject().
 * Warnings (a past start date, a duplicate name) are returned alongside the new
 * project rather than blocking the save.
 */
export function createProject(db, payload = {}, now) {
  const errors = validateProject(payload, { employees: db.employees });

  if (!isValid(errors)) {
    return { status: 400, body: { message: "Please fix the highlighted fields.", errors } };
  }

  const project = {
    id: nextId("prj", db.projects, db.counters),
    name: payload.name.trim(),
    description: payload.description.trim(),
    // Remove any duplicate ids that a client might send.
    employeeIds: [...new Set(payload.employeeIds)],
    complexity: payload.complexity.trim(),
    startDate: payload.startDate.trim(),
  };

  const warnings = getProjectWarnings(project, { projects: db.projects, now });
  const nextDb = {
    ...db,
    projects: [...db.projects, project],
    // Remember the number so this id is never handed out again.
    counters: rememberId(db.counters, "prj", project.id),
  };

  return {
    status: 201,
    body: { ...withDetails(project, db.employees, now), warnings },
    nextDb,
  };
}
