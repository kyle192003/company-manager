/**
 * project.service.js — what the application can do with projects.
 *
 * REQUIREMENTS covered here:
 *   - Create new projects with name, description, employees, complexity, start date
 *   - Search projects by name
 *
 * Same shape as employee.service.js: takes the database, returns
 * { status, body, nextDb? }, knows nothing about Express.
 */

import * as Project from "../models/project.model.js";
import { validateProject, getProjectWarnings } from "../validators/project.validator.js";
import { isValid } from "../validators/rules.js";
import { filterProjects, sortProjects } from "../utils/filters.js";

/**
 * The project list, each with its team and whether it has started.
 * Optional query: { search }
 */
export function listProjects(db, query = {}, now) {
  const matching = filterProjects(db.projects, { search: query.search ?? "" });
  const detailed = sortProjects(matching).map((project) =>
    Project.withEmployees(project, db.employees, now),
  );

  return { status: 200, body: detailed };
}

/** One project. */
export function getProject(db, id, now) {
  const project = Project.findById(db, id);
  if (!project) {
    return { status: 404, body: { message: `No project with id "${id}".` } };
  }

  return { status: 200, body: Project.withEmployees(project, db.employees, now) };
}

/**
 * Creates a project.
 *
 * LOGIC CHECK: the project must include at least one employee, and each chosen
 * employee must actually exist. Both are enforced by validateProject().
 * Warnings (a past start date, a duplicate name) are returned alongside the new
 * project rather than blocking the save.
 */
export function createProject(db, payload = {}, now) {
  const errors = validateProject(payload, { employees: db.employees });

  if (!isValid(errors)) {
    return { status: 400, body: { message: "Please fix the highlighted fields.", errors } };
  }

  const project = Project.build(db, payload);
  const warnings = getProjectWarnings(project, { projects: db.projects, now });

  return {
    status: 201,
    body: { ...Project.withEmployees(project, db.employees, now), warnings },
    nextDb: Project.add(db, project),
  };
}
