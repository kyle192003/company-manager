/**
 * employee.service.js — what the application can do with employees.
 *
 * REQUIREMENTS covered here:
 *   - Display a comprehensive list of employees
 *   - View individual employee details
 *   - Filter employees by department
 *   - Search employees by name
 *   - Add an employee
 *   - Delete an employee
 *
 * Each function takes the current database and returns { status, body }, plus
 * `nextDb` when the data changed. The controller turns that into an HTTP
 * response and saves the new database.
 *
 * WHY this shape: nothing here imports Express, so the tests call these
 * functions directly with a fake database — no server, no supertest, no faking
 * req and res. That is what lets almost the whole backend be covered by fast
 * unit tests.
 */

import * as Employee from "../models/employee.model.js";
import { validateEmployee } from "../validators/employee.validator.js";
import { findProjectsLeftEmptyBy } from "../validators/project.validator.js";
import { isValid } from "../validators/rules.js";
import { filterEmployees, sortEmployees, ALL_DEPARTMENTS } from "../utils/filters.js";

/**
 * The employee directory.
 * Optional query: { search, department }
 */
export function listEmployees(db, query = {}) {
  const matching = filterEmployees(db.employees, {
    search: query.search ?? "",
    department: query.department ?? ALL_DEPARTMENTS,
  });

  return { status: 200, body: sortEmployees(matching) };
}

/**
 * One employee, together with the projects they are assigned to, which is what
 * the details view shows.
 */
export function getEmployee(db, id) {
  const employee = Employee.findById(db, id);
  if (!employee) {
    return { status: 404, body: { message: `No employee with id "${id}".` } };
  }

  return { status: 200, body: { ...employee, projects: Employee.findProjects(db, id) } };
}

/**
 * Adds an employee.
 * Refuses with 400 and a per-field error map when the rules fail.
 */
export function createEmployee(db, payload = {}) {
  const errors = validateEmployee(payload, {
    employees: db.employees,
    departments: db.departments,
  });

  if (!isValid(errors)) {
    return { status: 400, body: { message: "Please fix the highlighted fields.", errors } };
  }

  const employee = Employee.build(db, payload);
  return { status: 201, body: employee, nextDb: Employee.add(db, employee) };
}

/**
 * Deletes an employee.
 *
 * LOGIC CHECK: a project must always keep at least one employee, so deleting
 * someone who is the only member of a project is refused with 409 and a message
 * naming those projects. Otherwise they are removed from the directory and from
 * every project they were on.
 */
export function deleteEmployee(db, id) {
  const employee = Employee.findById(db, id);
  if (!employee) {
    return { status: 404, body: { message: `No employee with id "${id}".` } };
  }

  const wouldEmpty = findProjectsLeftEmptyBy(id, db.projects);
  if (wouldEmpty.length > 0) {
    const names = wouldEmpty.map((project) => `"${project.name}"`).join(", ");
    return {
      status: 409,
      body: {
        message:
          `${employee.firstName} ${employee.lastName} is the only employee on ${names}. ` +
          "Add someone else to those projects first, because a project must have at least one employee.",
        blockingProjects: wouldEmpty.map(({ id: projectId, name }) => ({ id: projectId, name })),
      },
    };
  }

  return {
    status: 200,
    body: { message: "Employee deleted.", id },
    nextDb: Employee.remove(db, id),
  };
}
