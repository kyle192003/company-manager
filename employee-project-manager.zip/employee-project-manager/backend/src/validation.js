/**
 * validation.js — the business rules, with no knowledge of HTTP or of the database file.
 *
 * Every rule is a plain function that takes data and returns problems, which makes
 * them easy to unit test (see tests/validation.test.js) and easy to reuse.
 *
 * Two kinds of result:
 *   - errors   → block the save. Returned as { fieldName: "message" }.
 *   - warnings → do not block, but the UI shows them. Returned as an array of strings.
 *
 * LOGIC CHECK: "A project must have at least one employee" is enforced in
 * `validateProject()`, and again on delete by `findProjectsLeftEmptyBy()`.
 */

import { isValidDateString, hasStarted } from "./dates.js";

/** The only complexity values a project may have. */
export const COMPLEXITY_LEVELS = ["low", "medium", "high"];

/** Trims a value into a string, so undefined/null/numbers never crash a check. */
function text(value) {
  return typeof value === "string" ? value.trim() : "";
}

/** A deliberately forgiving email check: something@something.tld */
export function isValidEmail(value) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(text(value));
}

/**
 * Checks a new employee.
 * @param input       the submitted form values
 * @param employees   employees that already exist (used for the duplicate email check)
 * @param departments the allowed department names
 * @returns {} when valid, otherwise { field: "message" }
 */
export function validateEmployee(input = {}, { employees = [], departments = [] } = {}) {
  const errors = {};

  if (!text(input.firstName)) errors.firstName = "First name is required.";
  if (!text(input.lastName)) errors.lastName = "Last name is required.";
  if (!text(input.position)) errors.position = "Position is required.";

  // Email: required, well formed, and not already used by someone else.
  const email = text(input.email).toLowerCase();
  if (!email) {
    errors.email = "Email is required.";
  } else if (!isValidEmail(email)) {
    errors.email = "Enter a valid email address.";
  } else if (employees.some((employee) => text(employee.email).toLowerCase() === email)) {
    errors.email = "Another employee already uses this email.";
  }

  // Department must be one we actually offer, not free text.
  const department = text(input.department);
  if (!department) {
    errors.department = "Department is required.";
  } else if (departments.length > 0 && !departments.includes(department)) {
    errors.department = "Choose a department from the list.";
  }

  // Hire date is optional, but must be a real date when given.
  const hireDate = text(input.hireDate);
  if (hireDate && !isValidDateString(hireDate)) {
    errors.hireDate = "Enter a valid date.";
  }

  return errors;
}

/**
 * Checks a new project.
 * @param input     the submitted form values
 * @param employees employees that exist, so we can confirm the chosen ones are real
 * @returns {} when valid, otherwise { field: "message" }
 */
export function validateProject(input = {}, { employees = [] } = {}) {
  const errors = {};

  if (!text(input.name)) errors.name = "Project name is required.";
  if (!text(input.description)) errors.description = "Description is required.";

  // LOGIC CHECK: a project must include at least one existing employee.
  const employeeIds = Array.isArray(input.employeeIds) ? input.employeeIds : [];
  if (employeeIds.length === 0) {
    errors.employeeIds = "Assign at least one employee to this project.";
  } else {
    const knownIds = new Set(employees.map((employee) => employee.id));
    const unknown = employeeIds.filter((id) => !knownIds.has(id));
    if (unknown.length > 0) {
      errors.employeeIds = `These employees no longer exist: ${unknown.join(", ")}.`;
    }
  }

  // Complexity is a fixed choice, so anything else is a mistake.
  if (!COMPLEXITY_LEVELS.includes(text(input.complexity))) {
    errors.complexity = "Choose a complexity of low, medium or high.";
  }

  const startDate = text(input.startDate);
  if (!startDate) {
    errors.startDate = "Start date is required.";
  } else if (!isValidDateString(startDate)) {
    errors.startDate = "Enter a valid start date.";
  }

  return errors;
}

/**
 * Things worth telling the user about, that are not mistakes.
 * LOGIC CHECK: the "error messages/warnings" requirement — this is the warnings half.
 */
export function getProjectWarnings(input = {}, { projects = [], now } = {}) {
  const warnings = [];
  const startDate = text(input.startDate);

  // Backdating is allowed (you may be recording a project already underway),
  // but it is worth flagging because the project will appear as already started.
  if (isValidDateString(startDate) && hasStarted(startDate, now)) {
    warnings.push("This start date is today or in the past, so the project will show as already started.");
  }

  // A duplicate name is not fatal, but it usually means a double submission.
  const name = text(input.name).toLowerCase();
  if (name && projects.some((project) => text(project.name).toLowerCase() === name)) {
    warnings.push("Another project already has this name.");
  }

  return warnings;
}

/**
 * LOGIC CHECK: deleting an employee must never leave a project with no employees.
 * Returns the projects that would be emptied by removing this employee — an
 * empty array means the delete is safe.
 */
export function findProjectsLeftEmptyBy(employeeId, projects = []) {
  return projects.filter((project) => {
    const members = Array.isArray(project.employeeIds) ? project.employeeIds : [];
    if (!members.includes(employeeId)) return false;
    const remaining = members.filter((id) => id !== employeeId);
    return remaining.length === 0;
  });
}

/** True when an errors object from the functions above holds no problems. */
export function isValid(errors) {
  return Object.keys(errors).length === 0;
}
