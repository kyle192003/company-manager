/**
 * app.js — assembles the Express application.
 *
 * Middleware, then routes, then the two fallbacks. The order matters: the
 * not-found handler has to come after every router, and the error handler has
 * to come last of all.
 *
 * Kept separate from server.js so the app can be built without a port being
 * opened — which is what a supertest-style integration test would need.
 */

import express from "express";

import routes from "./routes/index.js";
import { cors } from "./middleware/cors.middleware.js";
import { notFound } from "./middleware/notFound.middleware.js";
import { errorHandler } from "./middleware/error.middleware.js";

export function createApp() {
  const app = express();

  // Parses JSON request bodies into req.body.
  app.use(express.json());
  app.use(cors);

  // Everything the API offers lives under /api.
  app.use("/api", routes);

  app.use(notFound);
  app.use(errorHandler);

  return app;
}

export default createApp;
