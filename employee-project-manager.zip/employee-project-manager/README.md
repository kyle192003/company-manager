# Employee & Project Manager

An employee directory and a project manager, in one page with two screens.
React + Vite + Tailwind on the front, Express on the back, and a JSON file as the database.

```
employee-project-manager/
├── backend/     Express API. Owns the data and the rules.
├── frontend/    React UI. Two screens and a tab switcher.
└── .github/     CI/CD: run tests, build, deploy to GitHub Pages.
```

The two folders are completely independent — each has its own `package.json`, its own
dependencies and its own tests. You can open, run and explain either one on its own.

---

## Running it

You need **Node 22.12 or newer** (`node --version`). Two terminals:

**Terminal 1 — the API**

```bash
cd backend
npm install
npm start          # http://localhost:4000
```

**Terminal 2 — the UI**

```bash
cd frontend
npm install
npm run dev        # http://localhost:5173, opens automatically
```

Anything you add or delete is written to `backend/data/db.json`.
`npm run reset-db` in the backend folder puts the sample data back.

---

## The two screens

**Employee Directory** — the list of everyone, with a name search and a department
filter. **View** opens their details and the projects they are on. **Add employee**
and **Delete** are here too.

**Projects** — one card per project, showing its team, its complexity and whether it
has already started. Search by name, and **New project** creates one.

Everything else — details, both forms, the delete confirmation — opens as a pop-up on
top of these two screens, so the app never leaves the page.

---

## Where each requirement lives

Every file is commented, and the comments are tagged so you can find these quickly:
`REQUIREMENT:`, `LOGIC CHECK:`, `BONUS:`.

### Employee Directory

| Requirement | Front end | Back end |
| --- | --- | --- |
| List all employees | `components/EmployeeTable.jsx` | `GET /api/employees` |
| View one employee's details | `components/EmployeeDetails.jsx` | `GET /api/employees/:id` |
| Filter by department | `lib/filters.js` → `filterEmployees` | same rule in `src/filters.js` |
| Search by name | `lib/filters.js` → `filterEmployees` | same rule in `src/filters.js` |
| Add an employee | `components/AddEmployeeForm.jsx` | `POST /api/employees` |
| Delete an employee | `components/ConfirmDelete.jsx` | `DELETE /api/employees/:id` |

### Project Management

| Requirement | Front end | Back end |
| --- | --- | --- |
| Create a project (name, description, employees, complexity, start date) | `components/NewProjectForm.jsx` | `POST /api/projects` |
| Search projects by name | `lib/filters.js` → `filterProjects` | `GET /api/projects?search=` |

### Logic checks

| Check | Where |
| --- | --- |
| A project must have at least one employee | `validation.js` → `validateProject`, in **both** folders |
| …and deleting someone must never empty a project | `validation.js` → `findProjectsLeftEmptyBy`, in both folders |
| Show whether a project has already started | `dates.js` → `describeStart`, shown by `components/Badge.jsx` |
| Show errors and warnings | `components/Field.jsx` (per field) and `components/Alert.jsx` (banners) |

---

## Two questions people ask about this design

**Why are the validation rules written in both folders?**
Because they do two different jobs. The copy in the browser gives an instant, per-field
message as you type. The copy on the server is the authority — it runs again on every
request, so bad data cannot get in even from a hand-made request or a second browser tab
that has gone stale. The two folders stay independent, with no shared build step.

**Why does searching not call the server?**
The UI loads the list once and filters it in the browser, so typing updates the table on
every keystroke with no round trip. The API supports `?search=` and `?department=` as
well, and those are tested — that is the path to switch to when the directory grows too
large to send in one go.

---

## Tests

```bash
cd backend  && npm test      # 53 tests
cd frontend && npm test      # 44 logic tests + component tests
```

The brief asks for one passing unit test; the bonus asks for at least five covering both
front and back. This goes well past that on both counts.

**Backend** — `node --test`, Node's own test runner, so there is nothing extra to install.
The route handlers are plain functions that take the database and return
`{ status, body }`, which is what lets the tests cover the whole API without starting a
server. `tests/db.test.js` runs against a throwaway file, so your real data is untouched.

**Frontend** — Vitest with React Testing Library. `dates`, `filters` and `validation` test
the rules directly; `EmployeeDirectory`, `NewProjectForm` and `App` render the real
components and click through them with a stand-in API client.

---

## CI/CD

`.github/workflows/ci.yml` runs on every push and pull request to `main`:

1. install and test the backend,
2. install and test the frontend,
3. build the frontend,
4. on `main` only, and only if everything passed, deploy it to GitHub Pages.

Enable it once: **Settings → Pages → Build and deployment → Source: GitHub Actions**.

**About the deployed copy.** GitHub Pages only serves static files, so there is no Node
process there to run Express. The Pages build sets `VITE_DEMO_MODE=true`, which swaps the
API client for an in-memory one (`frontend/src/api/demoClient.js`) holding the same sample
data and applying the same rules. A banner on the page says so, and changes are lost on
refresh. Run it locally for the real thing.

---

## Publishing this to GitHub

The project is already a git repository with its first commit made. Create an **empty
public** repository at <https://github.com/new> — no README, no .gitignore, no licence —
then:

```bash
git remote add origin https://github.com/<your-username>/employee-project-manager.git
git push -u origin main
```

The workflow runs on that first push. Once it finishes, turn Pages on as above and the
demo goes live at `https://<your-username>.github.io/employee-project-manager/`.

---

## The API

Base URL `http://localhost:4000`.

| Method | Path | Does |
| --- | --- | --- |
| `GET` | `/api/employees?search=&department=` | List employees |
| `GET` | `/api/employees/:id` | One employee, with their projects |
| `POST` | `/api/employees` | Add an employee |
| `DELETE` | `/api/employees/:id` | Delete an employee |
| `GET` | `/api/projects?search=` | List projects, each with its team |
| `GET` | `/api/projects/:id` | One project |
| `POST` | `/api/projects` | Create a project |
| `GET` | `/api/meta` | Departments, complexity levels, today's date |
| `GET` | `/api/health` | Is the API up |

A rejected save comes back as `400` with a message per field:

```json
{
  "message": "Please fix the highlighted fields.",
  "errors": { "employeeIds": "Assign at least one employee to this project." }
}
```

A delete that would empty a project comes back as `409`, naming the projects in the way.
The forms show these messages against the field they belong to.
