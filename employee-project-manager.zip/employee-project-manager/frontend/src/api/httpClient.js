/**
 * httpClient.js — talks to the Express API in backend/.
 *
 * Every method returns a promise and throws an ApiError when the server refuses
 * the request, so the screens can show the server's own field messages.
 */

/**
 * An error carrying what the server said.
 * `errors` is the { field: message } map the API returns for a failed
 * validation, which the forms use to mark individual inputs.
 */
export class ApiError extends Error {
  constructor(message, { status = 0, errors = {} } = {}) {
    super(message);
    this.name = "ApiError";
    this.status = status;
    this.errors = errors;
  }
}

/** Where the API lives. Override with VITE_API_URL in a .env file if needed. */
export const DEFAULT_API_URL = "http://localhost:4000";

export function createHttpClient(baseUrl = DEFAULT_API_URL) {
  /**
   * One place for every request: builds the URL, sends JSON, and turns a
   * non-2xx response into an ApiError.
   */
  async function request(path, options = {}) {
    let response;

    try {
      response = await fetch(`${baseUrl}${path}`, {
        headers: { "Content-Type": "application/json" },
        ...options,
        body: options.body ? JSON.stringify(options.body) : undefined,
      });
    } catch {
      // fetch only rejects when the network itself failed — usually the API is
      // not running. Say that plainly rather than showing a browser message.
      throw new ApiError(
        `Cannot reach the API at ${baseUrl}. Start it with "npm start" in the backend folder.`,
        { status: 0 },
      );
    }

    // 204 has no body to parse.
    const data = response.status === 204 ? null : await response.json().catch(() => null);

    if (!response.ok) {
      throw new ApiError(data?.message ?? `Request failed (${response.status}).`, {
        status: response.status,
        errors: data?.errors ?? {},
      });
    }

    return data;
  }

  return {
    /** Whether changes are saved to the JSON file (true) or only in the browser. */
    isDemo: false,

    /** Departments and complexity levels, so the UI never hard-codes them. */
    getMeta: () => request("/api/meta"),

    /** REQUIREMENT: display a comprehensive list of employees. */
    getEmployees: () => request("/api/employees"),

    /** REQUIREMENT: view individual employee details, with their projects. */
    getEmployee: (id) => request(`/api/employees/${encodeURIComponent(id)}`),

    /** REQUIREMENT: add an employee. */
    createEmployee: (payload) => request("/api/employees", { method: "POST", body: payload }),

    /** REQUIREMENT: delete an employee. */
    deleteEmployee: (id) =>
      request(`/api/employees/${encodeURIComponent(id)}`, { method: "DELETE" }),

    /** REQUIREMENT: list projects. */
    getProjects: () => request("/api/projects"),

    /** REQUIREMENT: create a new project. */
    createProject: (payload) => request("/api/projects", { method: "POST", body: payload }),
  };
}
