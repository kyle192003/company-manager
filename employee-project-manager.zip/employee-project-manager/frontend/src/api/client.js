/**
 * client.js — picks which data source the app talks to.
 *
 *   normal build  → httpClient, which calls the Express API and saves to db.json
 *   demo build    → demoClient, which keeps everything in memory
 *
 * The GitHub Pages workflow builds with VITE_DEMO_MODE=true, because Pages can
 * only serve static files and cannot run the Node server.
 *
 * Both clients expose exactly the same methods, so no component needs to know
 * which one it is using — and tests can pass a third, fake one.
 */

import { createHttpClient, DEFAULT_API_URL } from "./httpClient.js";
import { createDemoClient } from "./demoClient.js";

/** Reads a Vite environment variable, tolerating test runs where it is undefined. */
function readEnv(name, fallback = "") {
  return import.meta.env?.[name] ?? fallback;
}

/** True when this build has no backend to talk to. */
export const isDemoMode = readEnv("VITE_DEMO_MODE") === "true";

/** The client the app uses. Created once, at start-up. */
export function createClient() {
  if (isDemoMode) return createDemoClient();
  return createHttpClient(readEnv("VITE_API_URL", DEFAULT_API_URL));
}
