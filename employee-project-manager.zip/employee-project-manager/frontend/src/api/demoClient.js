/**
 * demoClient.js — a stand-in for the API, used only by the GitHub Pages build.
 *
 * GitHub Pages can only serve static files, so there is no Node process there to
 * run the Express server. This client keeps the same data in memory and applies
 * the same rules, so the deployed demo behaves like the real thing. Changes are
 * lost when the page is refreshed.
 *
 * Locally, `npm run dev` uses httpClient.js instead and writes to db.json.
 */

import seed from "../lib/demoSeed.json";
import { COMPLEXITY_LEVELS, validateEmployee, validateProject, getProjectWarnings, findProjectsLeftEmptyBy, isValid } from "../lib/validation.js";
import { hasStarted, today } from "../lib/dates.js";
import { ApiError } from "./httpClient.js";

/** Highest id number in a list: ["emp-1", "emp-12"] → 12. */
function highestId(items) {
  return items.reduce((max, item) => {
    const match = String(item.id ?? "").match(/(\d+)$/);
    return Math.max(max, match ? Number(match[1]) : 0);
  }, 0);
}

export function createDemoClient() {
  // A deep copy, so editing never changes the imported seed data.
  const db = structuredClone(seed);
  // Mirrors the backend: ids are never reused, even after a delete.
  const counters = { emp: highestId(db.employees), prj: highestId(db.projects) };

  /** Attaches full employee records and the started flag, as the API does. */
  function withDetails(project) {
    return {
      ...project,
      employees: project.employeeIds
        .map((id) => db.employees.find((employee) => employee.id === id))
        .filter(Boolean),
      hasStarted: hasStarted(project.startDate),
    };
  }

  return {
    /** The UI shows a banner when this is true. */
    isDemo: true,

    async getMeta() {
      return {
        departments: [...db.departments],
        complexityLevels: COMPLEXITY_LEVELS,
        today: today(),
      };
    },

    async getEmployees() {
      return structuredClone(db.employees);
    },

    async getEmployee(id) {
      const employee = db.employees.find((candidate) => candidate.id === id);
      if (!employee) throw new ApiError(`No employee with id "${id}".`, { status: 404 });

      return {
        ...structuredClone(employee),
        projects: structuredClone(
          db.projects.filter((project) => project.employeeIds.includes(id)),
        ),
      };
    },

    async createEmployee(payload) {
      const errors = validateEmployee(payload, {
        employees: db.employees,
        departments: db.departments,
      });
      if (!isValid(errors)) {
        throw new ApiError("Please fix the highlighted fields.", { status: 400, errors });
      }

      counters.emp += 1;
      const employee = {
        id: `emp-${counters.emp}`,
        firstName: payload.firstName.trim(),
        lastName: payload.lastName.trim(),
        email: payload.email.trim(),
        position: payload.position.trim(),
        department: payload.department.trim(),
        hireDate: payload.hireDate?.trim() || today(),
      };

      db.employees.push(employee);
      return structuredClone(employee);
    },

    async deleteEmployee(id) {
      const employee = db.employees.find((candidate) => candidate.id === id);
      if (!employee) throw new ApiError(`No employee with id "${id}".`, { status: 404 });

      // LOGIC CHECK: never leave a project with no employees.
      const wouldEmpty = findProjectsLeftEmptyBy(id, db.projects);
      if (wouldEmpty.length > 0) {
        const names = wouldEmpty.map((project) => `"${project.name}"`).join(", ");
        throw new ApiError(
          `${employee.firstName} ${employee.lastName} is the only employee on ${names}. ` +
            "Add someone else to those projects first, because a project must have at least one employee.",
          { status: 409 },
        );
      }

      db.employees = db.employees.filter((candidate) => candidate.id !== id);
      for (const project of db.projects) {
        project.employeeIds = project.employeeIds.filter((memberId) => memberId !== id);
      }

      return { message: "Employee deleted.", id };
    },

    async getProjects() {
      return db.projects.map((project) => structuredClone(withDetails(project)));
    },

    async createProject(payload) {
      const errors = validateProject(payload, { employees: db.employees });
      if (!isValid(errors)) {
        throw new ApiError("Please fix the highlighted fields.", { status: 400, errors });
      }

      counters.prj += 1;
      const project = {
        id: `prj-${counters.prj}`,
        name: payload.name.trim(),
        description: payload.description.trim(),
        employeeIds: [...new Set(payload.employeeIds)],
        complexity: payload.complexity.trim(),
        startDate: payload.startDate.trim(),
      };

      const warnings = getProjectWarnings(project, { projects: db.projects });
      db.projects.push(project);

      return { ...structuredClone(withDetails(project)), warnings };
    },
  };
}
