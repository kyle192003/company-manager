/**
 * Tests for the start-date rule in the UI.
 * LOGIC CHECK: "UI must indicate if a project has already started based on the start date."
 */

import { describe, it, expect } from "vitest";

import { hasStarted, describeStart, isValidDateString, formatDate } from "../lib/dates.js";
import { TODAY } from "./fixtures.js";

describe("hasStarted", () => {
  it("counts a project beginning before today as started", () => {
    expect(hasStarted("2026-06-01", TODAY)).toBe(true);
  });

  it("counts a project beginning today as started", () => {
    expect(hasStarted(TODAY, TODAY)).toBe(true);
  });

  it("does not count a project beginning tomorrow", () => {
    expect(hasStarted("2026-09-23", TODAY)).toBe(false);
  });

  it("treats a missing or malformed date as not started", () => {
    expect(hasStarted("", TODAY)).toBe(false);
    expect(hasStarted("not a date", TODAY)).toBe(false);
  });
});

describe("describeStart", () => {
  it("counts down the days to a future project", () => {
    expect(describeStart("2026-10-05", TODAY)).toEqual({
      started: false,
      days: 13,
      label: "Starts in 13 days",
    });
  });

  it("counts up the days since a project began", () => {
    const status = describeStart("2026-09-01", TODAY);
    expect(status.started).toBe(true);
    expect(status.label).toBe("Started 21 days ago");
  });

  it("says 'Starts today' rather than counting zero days", () => {
    expect(describeStart(TODAY, TODAY).label).toBe("Starts today");
  });

  it("uses the singular for exactly one day", () => {
    expect(describeStart("2026-09-23", TODAY).label).toBe("Starts in 1 day");
    expect(describeStart("2026-09-21", TODAY).label).toBe("Started 1 day ago");
  });
});

describe("isValidDateString", () => {
  it("rejects a day that does not exist", () => {
    // new Date() would quietly turn this into 2 March.
    expect(isValidDateString("2026-02-30")).toBe(false);
  });

  it("accepts a real date", () => {
    expect(isValidDateString("2026-02-28")).toBe(true);
  });

  it("rejects other formats", () => {
    expect(isValidDateString("22/09/2026")).toBe(false);
  });
});

describe("formatDate", () => {
  it("writes a date the way the UI shows it", () => {
    expect(formatDate("2026-10-05")).toBe("5 October 2026");
  });

  it("falls back to a dash when there is no date", () => {
    expect(formatDate("")).toBe("—");
  });
});
