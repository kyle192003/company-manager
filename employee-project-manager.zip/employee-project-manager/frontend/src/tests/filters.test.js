/**
 * Tests for the search and filter rules.
 * REQUIREMENT: search employees by name, filter by department, search projects by name.
 */

import { describe, it, expect } from "vitest";

import {
  filterEmployees,
  filterProjects,
  sortEmployees,
  fullName,
  ALL_DEPARTMENTS,
} from "../lib/filters.js";
import { EMPLOYEES, PROJECTS } from "./fixtures.js";

describe("filterEmployees", () => {
  it("returns everyone when nothing is set", () => {
    expect(filterEmployees(EMPLOYEES, {})).toHaveLength(3);
  });

  it("matches part of a first name, ignoring case", () => {
    const found = filterEmployees(EMPLOYEES, { search: "MAR" });
    expect(found.map((employee) => employee.id)).toEqual(["emp-1"]);
  });

  it("matches a last name too", () => {
    expect(filterEmployees(EMPLOYEES, { search: "reyes" })).toHaveLength(1);
  });

  it("matches across the first and last name together", () => {
    expect(filterEmployees(EMPLOYEES, { search: "maria san" })).toHaveLength(1);
  });

  it("ignores spaces around the search text", () => {
    expect(filterEmployees(EMPLOYEES, { search: "  bea  " })).toHaveLength(1);
  });

  it("filters by department", () => {
    const found = filterEmployees(EMPLOYEES, { department: "Design" });
    expect(found.map((employee) => employee.firstName)).toEqual(["Paolo"]);
  });

  it("applies the search and the department together", () => {
    expect(filterEmployees(EMPLOYEES, { search: "maria", department: "Design" })).toHaveLength(0);
    expect(
      filterEmployees(EMPLOYEES, { search: "maria", department: "Engineering" }),
    ).toHaveLength(1);
  });

  it("shows every department when the filter is All", () => {
    expect(filterEmployees(EMPLOYEES, { department: ALL_DEPARTMENTS })).toHaveLength(3);
  });

  it("returns nothing when nothing matches", () => {
    expect(filterEmployees(EMPLOYEES, { search: "zzzz" })).toEqual([]);
  });
});

describe("filterProjects", () => {
  it("matches part of a project name", () => {
    const found = filterProjects(PROJECTS, { search: "portal" });
    expect(found.map((project) => project.id)).toEqual(["prj-1"]);
  });

  it("returns every project for an empty search", () => {
    expect(filterProjects(PROJECTS, { search: "" })).toHaveLength(2);
  });
});

describe("sortEmployees", () => {
  it("sorts by last name", () => {
    const sorted = sortEmployees(EMPLOYEES);
    expect(sorted.map((employee) => employee.lastName)).toEqual(["Navarro", "Reyes", "Santos"]);
  });

  it("does not change the array it was given", () => {
    const original = [...EMPLOYEES];
    sortEmployees(EMPLOYEES);
    expect(EMPLOYEES).toEqual(original);
  });
});

describe("fullName", () => {
  it("joins the first and last name", () => {
    expect(fullName(EMPLOYEES[0])).toBe("Maria Santos");
  });
});
