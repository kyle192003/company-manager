/**
 * Tests for the rules the forms apply.
 * LOGIC CHECK: "A project must have at least one employee."
 */

import { describe, it, expect } from "vitest";

import {
  validateEmployee,
  validateProject,
  getProjectWarnings,
  findProjectsLeftEmptyBy,
  isValid,
} from "../lib/validation.js";
import { EMPLOYEES, PROJECTS, DEPARTMENTS, TODAY } from "./fixtures.js";

/** A form that would save cleanly, which each test then breaks on purpose. */
const goodEmployee = {
  firstName: "Grace",
  lastName: "Lim",
  email: "grace.lim@example.com",
  position: "QA Engineer",
  department: "Engineering",
};

const goodProject = {
  name: "Internal API Gateway",
  description: "Put internal traffic behind one gateway.",
  employeeIds: ["emp-1"],
  complexity: "high",
  startDate: "2026-12-01",
};

const context = { employees: EMPLOYEES, departments: DEPARTMENTS };

describe("validateEmployee", () => {
  it("accepts a complete form", () => {
    expect(isValid(validateEmployee(goodEmployee, context))).toBe(true);
  });

  it("reports every empty required field at once", () => {
    const errors = validateEmployee({}, context);
    expect(Object.keys(errors).sort()).toEqual([
      "department",
      "email",
      "firstName",
      "lastName",
      "position",
    ]);
  });

  it("rejects an email already in the directory, whatever the capitals", () => {
    const errors = validateEmployee(
      { ...goodEmployee, email: "MARIA.SANTOS@example.com" },
      context,
    );
    expect(errors.email).toMatch(/already uses this email/);
  });

  it("rejects an email with no @", () => {
    const errors = validateEmployee({ ...goodEmployee, email: "grace.lim.example" }, context);
    expect(errors.email).toMatch(/valid email/);
  });

  it("rejects a department that is not on the list", () => {
    const errors = validateEmployee({ ...goodEmployee, department: "Legal" }, context);
    expect(errors.department).toMatch(/from the list/);
  });

  it("treats whitespace as empty", () => {
    const errors = validateEmployee({ ...goodEmployee, firstName: "   " }, context);
    expect(errors.firstName).toBeDefined();
  });
});

describe("validateProject", () => {
  it("accepts a complete form", () => {
    expect(isValid(validateProject(goodProject, { employees: EMPLOYEES }))).toBe(true);
  });

  it("LOGIC CHECK: rejects a project with no employees", () => {
    const errors = validateProject({ ...goodProject, employeeIds: [] }, { employees: EMPLOYEES });
    expect(errors.employeeIds).toMatch(/at least one employee/);
  });

  it("rejects an employee who is not in the directory", () => {
    const errors = validateProject(
      { ...goodProject, employeeIds: ["emp-999"] },
      { employees: EMPLOYEES },
    );
    expect(errors.employeeIds).toMatch(/emp-999/);
  });

  it("rejects a complexity outside low, medium and high", () => {
    const errors = validateProject(
      { ...goodProject, complexity: "urgent" },
      { employees: EMPLOYEES },
    );
    expect(errors.complexity).toMatch(/low, medium or high/);
  });

  it("requires a start date", () => {
    const errors = validateProject({ ...goodProject, startDate: "" }, { employees: EMPLOYEES });
    expect(errors.startDate).toMatch(/required/);
  });
});

describe("getProjectWarnings", () => {
  it("warns about a start date in the past without blocking it", () => {
    const input = { ...goodProject, startDate: "2026-01-05" };

    expect(isValid(validateProject(input, { employees: EMPLOYEES }))).toBe(true);
    expect(getProjectWarnings(input, { projects: PROJECTS, now: TODAY })).toEqual([
      expect.stringMatching(/already started/),
    ]);
  });

  it("warns about a name another project already uses", () => {
    const warnings = getProjectWarnings(
      { ...goodProject, name: "customer portal redesign", startDate: "2026-12-01" },
      { projects: PROJECTS, now: TODAY },
    );
    expect(warnings).toEqual([expect.stringMatching(/already has this name/)]);
  });

  it("says nothing about an ordinary project", () => {
    expect(getProjectWarnings(goodProject, { projects: PROJECTS, now: TODAY })).toEqual([]);
  });
});

describe("findProjectsLeftEmptyBy", () => {
  it("LOGIC CHECK: flags the employee who is a project's only member", () => {
    const blocked = findProjectsLeftEmptyBy("emp-3", PROJECTS);
    expect(blocked.map((project) => project.name)).toEqual(["Budget Dashboard"]);
  });

  it("allows deleting someone whose projects have other members", () => {
    expect(findProjectsLeftEmptyBy("emp-1", PROJECTS)).toEqual([]);
  });

  it("allows deleting someone on no projects at all", () => {
    expect(findProjectsLeftEmptyBy("emp-999", PROJECTS)).toEqual([]);
  });
});
