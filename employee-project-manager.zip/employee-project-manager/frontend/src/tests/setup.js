/**
 * setup.js — runs once before the tests.
 *
 * It adds the extra expect() matchers from jest-dom, such as
 * toBeInTheDocument() and toBeDisabled(), which read better than checking
 * for null by hand.
 *
 * Wired in by the `setupFiles` option in vite.config.js.
 */

import "@testing-library/jest-dom/vitest";
