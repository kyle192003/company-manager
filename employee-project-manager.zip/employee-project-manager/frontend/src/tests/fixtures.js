/**
 * fixtures.js — sample data and a stand-in API client for the tests.
 *
 * The components take their client as a prop, so the tests hand them this fake
 * one instead of the real thing. No network, no server, and each test can decide
 * exactly what the "server" replies.
 */

import { ApiError } from "../api/httpClient.js";

/** A fixed "today", so a test never starts failing because time passed. */
export const TODAY = "2026-09-22";

export const EMPLOYEES = [
  {
    id: "emp-1",
    firstName: "Maria",
    lastName: "Santos",
    email: "maria.santos@example.com",
    position: "Senior Software Engineer",
    department: "Engineering",
    hireDate: "2021-03-15",
  },
  {
    id: "emp-2",
    firstName: "Paolo",
    lastName: "Reyes",
    email: "paolo.reyes@example.com",
    position: "Product Designer",
    department: "Design",
    hireDate: "2020-11-02",
  },
  {
    id: "emp-3",
    firstName: "Bea",
    lastName: "Navarro",
    email: "bea.navarro@example.com",
    position: "Accountant",
    department: "Finance",
    hireDate: "2024-04-01",
  },
];

export const PROJECTS = [
  {
    // Already under way, and shared by two people.
    id: "prj-1",
    name: "Customer Portal Redesign",
    description: "Rebuild the portal.",
    employeeIds: ["emp-1", "emp-2"],
    complexity: "high",
    startDate: "2026-06-01",
    hasStarted: true,
    employees: [EMPLOYEES[0], EMPLOYEES[1]],
  },
  {
    // Still to come, and Bea is its only member.
    id: "prj-2",
    name: "Budget Dashboard",
    description: "Roll up departmental spend.",
    employeeIds: ["emp-3"],
    complexity: "medium",
    startDate: "2026-11-03",
    hasStarted: false,
    employees: [EMPLOYEES[2]],
  },
];

export const DEPARTMENTS = ["Design", "Engineering", "Finance"];

/**
 * A stand-in for the API.
 * Pass `overrides` to change one method for a single test, e.g. to make
 * createEmployee reject the way the server would.
 */
export function createFakeClient(overrides = {}) {
  return {
    isDemo: false,

    getMeta: async () => ({
      departments: DEPARTMENTS,
      complexityLevels: ["low", "medium", "high"],
      today: TODAY,
    }),

    getEmployees: async () => structuredClone(EMPLOYEES),

    getEmployee: async (id) => {
      const employee = EMPLOYEES.find((candidate) => candidate.id === id);
      return {
        ...structuredClone(employee),
        projects: structuredClone(
          PROJECTS.filter((project) => project.employeeIds.includes(id)),
        ),
      };
    },

    createEmployee: async (payload) => ({ id: "emp-99", ...payload }),
    deleteEmployee: async (id) => ({ message: "Employee deleted.", id }),

    getProjects: async () => structuredClone(PROJECTS),
    createProject: async (payload) => ({
      id: "prj-99",
      ...payload,
      employees: [],
      hasStarted: false,
      warnings: [],
    }),

    ...overrides,
  };
}

/** Builds the error a real server would send for a failed validation. */
export function validationError(errors, message = "Please fix the highlighted fields.") {
  return new ApiError(message, { status: 400, errors });
}

export { ApiError };
