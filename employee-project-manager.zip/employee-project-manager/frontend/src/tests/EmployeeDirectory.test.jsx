/**
 * Tests for the Employee Directory screen.
 *
 * REQUIREMENTS: list employees, search by name, filter by department, delete.
 * LOGIC CHECK: deleting the only employee on a project is refused.
 *
 * The screen receives its data as props, so these tests render it directly with
 * the fixtures and a stand-in client — no server and no network involved.
 */

import { describe, it, expect, vi } from "vitest";
import { render, screen, fireEvent, waitFor, within } from "@testing-library/react";

import EmployeeDirectory from "../screens/EmployeeDirectory.jsx";
import {
  createFakeClient,
  ApiError,
  EMPLOYEES,
  PROJECTS,
  DEPARTMENTS,
  TODAY,
} from "./fixtures.js";

/** Renders the screen with sensible defaults, overridable per test. */
function renderScreen(props = {}) {
  const client = props.client ?? createFakeClient();
  const onDataChanged = props.onDataChanged ?? vi.fn();
  const onNotify = props.onNotify ?? vi.fn();

  render(
    <EmployeeDirectory
      client={client}
      employees={EMPLOYEES}
      projects={PROJECTS}
      departments={DEPARTMENTS}
      today={TODAY}
      onDataChanged={onDataChanged}
      onNotify={onNotify}
      {...props}
    />,
  );

  return { client, onDataChanged, onNotify };
}

/** The employee rows currently on screen. */
function visibleRows() {
  return within(screen.getByRole("table")).getAllByRole("row").slice(1); // drop the header row
}

describe("the employee list", () => {
  it("REQUIREMENT: shows every employee", () => {
    renderScreen();

    expect(visibleRows()).toHaveLength(3);
    expect(screen.getByText("Maria Santos")).toBeInTheDocument();
    expect(screen.getByText("Paolo Reyes")).toBeInTheDocument();
    expect(screen.getByText("Bea Navarro")).toBeInTheDocument();
  });

  it("shows how many employees there are", () => {
    renderScreen();
    expect(screen.getByText("3 employees")).toBeInTheDocument();
  });
});

describe("searching by name", () => {
  it("REQUIREMENT: narrows the list as you type", () => {
    renderScreen();

    fireEvent.change(screen.getByLabelText("Search employees by name"), {
      target: { value: "mar" },
    });

    expect(visibleRows()).toHaveLength(1);
    expect(screen.getByText("Maria Santos")).toBeInTheDocument();
  });

  it("explains an empty result instead of showing a blank table", () => {
    renderScreen();

    fireEvent.change(screen.getByLabelText("Search employees by name"), {
      target: { value: "zzzz" },
    });

    expect(screen.getByText("No employees match your search.")).toBeInTheDocument();
  });
});

describe("filtering by department", () => {
  it("REQUIREMENT: shows only that department", () => {
    renderScreen();

    fireEvent.change(screen.getByLabelText("Filter by department"), {
      target: { value: "Design" },
    });

    expect(visibleRows()).toHaveLength(1);
    expect(screen.getByText("Paolo Reyes")).toBeInTheDocument();
  });

  it("combines with the name search", () => {
    renderScreen();

    fireEvent.change(screen.getByLabelText("Filter by department"), {
      target: { value: "Design" },
    });
    fireEvent.change(screen.getByLabelText("Search employees by name"), {
      target: { value: "maria" },
    });

    // Maria is in Engineering, so nothing matches both.
    expect(screen.getByText("No employees match your search.")).toBeInTheDocument();
  });

  it("puts everything back with Clear", () => {
    renderScreen();

    fireEvent.change(screen.getByLabelText("Filter by department"), {
      target: { value: "Design" },
    });
    fireEvent.click(screen.getByRole("button", { name: "Clear" }));

    expect(visibleRows()).toHaveLength(3);
  });
});

describe("deleting an employee", () => {
  it("LOGIC CHECK: refuses to delete the only employee on a project", () => {
    renderScreen();

    // Bea Navarro is the sole member of "Budget Dashboard".
    fireEvent.click(screen.getByRole("button", { name: "Delete Bea Navarro" }));

    expect(screen.getByText("This employee cannot be deleted")).toBeInTheDocument();
    expect(screen.getByText("Budget Dashboard")).toBeInTheDocument();
    expect(screen.getByRole("button", { name: "Delete employee" })).toBeDisabled();
  });

  it("allows deleting someone whose projects keep other members", async () => {
    const client = createFakeClient();
    const deleteEmployee = vi.fn(async (id) => ({ message: "Employee deleted.", id }));
    const { onNotify } = renderScreen({ client: { ...client, deleteEmployee } });

    // Maria Santos shares "Customer Portal Redesign" with Paolo.
    fireEvent.click(screen.getByRole("button", { name: "Delete Maria Santos" }));

    const confirm = screen.getByRole("button", { name: "Delete employee" });
    expect(confirm).not.toBeDisabled();
    expect(screen.getByText("They will be removed from these projects")).toBeInTheDocument();

    fireEvent.click(confirm);

    await waitFor(() => expect(deleteEmployee).toHaveBeenCalledWith("emp-1"));
    await waitFor(() =>
      expect(onNotify).toHaveBeenCalledWith("Maria Santos was removed from the directory."),
    );
  });

  it("shows the server's refusal if the data changed since the pop-up opened", async () => {
    const deleteEmployee = vi.fn(async () => {
      throw new ApiError("Maria Santos is the only employee on \"Customer Portal Redesign\".", {
        status: 409,
      });
    });
    renderScreen({ client: { ...createFakeClient(), deleteEmployee } });

    fireEvent.click(screen.getByRole("button", { name: "Delete Maria Santos" }));
    fireEvent.click(screen.getByRole("button", { name: "Delete employee" }));

    expect(
      await screen.findByText(/is the only employee on "Customer Portal Redesign"/),
    ).toBeInTheDocument();
  });
});

describe("the details pop-up", () => {
  it("REQUIREMENT: shows one employee and the projects they are on", async () => {
    renderScreen();

    fireEvent.click(screen.getByRole("button", { name: "View details for Maria Santos" }));

    const dialog = await screen.findByRole("dialog");
    expect(within(dialog).getByText("Maria Santos")).toBeInTheDocument();
    expect(await within(dialog).findByText("Customer Portal Redesign")).toBeInTheDocument();
    expect(within(dialog).getByText("maria.santos@example.com")).toBeInTheDocument();
  });
});
