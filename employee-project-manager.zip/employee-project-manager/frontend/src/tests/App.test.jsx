/**
 * Tests for the page itself — the part that loads the data and switches between
 * the two screens.
 *
 * LOGIC CHECK: the UI must say when something went wrong, rather than showing an
 * empty directory as though there were simply no employees.
 */

import { describe, it, expect, vi } from "vitest";
import { render, screen, fireEvent, waitFor } from "@testing-library/react";

import App from "../App.jsx";
import { createFakeClient, ApiError } from "./fixtures.js";

describe("loading", () => {
  it("shows the employee directory once the data arrives", async () => {
    render(<App client={createFakeClient()} />);

    expect(await screen.findByText("Maria Santos")).toBeInTheDocument();
    expect(screen.getByRole("heading", { name: "Employee directory" })).toBeInTheDocument();
  });

  it("asks for everything at once rather than one call after another", async () => {
    const client = createFakeClient();
    const getEmployees = vi.fn(client.getEmployees);
    const getProjects = vi.fn(client.getProjects);

    render(<App client={{ ...client, getEmployees, getProjects }} />);

    await screen.findByText("Maria Santos");
    expect(getEmployees).toHaveBeenCalledTimes(1);
    expect(getProjects).toHaveBeenCalledTimes(1);
  });
});

describe("switching screens", () => {
  it("starts on the Employee Directory", async () => {
    render(<App client={createFakeClient()} />);

    await screen.findByText("Maria Santos");
    expect(screen.getByRole("tab", { name: /Employee Directory/ })).toHaveAttribute(
      "aria-selected",
      "true",
    );
  });

  it("shows the projects when the Projects tab is chosen", async () => {
    render(<App client={createFakeClient()} />);
    await screen.findByText("Maria Santos");

    fireEvent.click(screen.getByRole("tab", { name: /Projects/ }));

    expect(await screen.findByText("Customer Portal Redesign")).toBeInTheDocument();
    expect(screen.getByRole("heading", { name: "Projects" })).toBeInTheDocument();
    // The directory is gone, not merely hidden.
    expect(screen.queryByRole("table")).not.toBeInTheDocument();
  });

  it("LOGIC CHECK: marks which projects have already started", async () => {
    render(<App client={createFakeClient()} />);
    await screen.findByText("Maria Santos");

    fireEvent.click(screen.getByRole("tab", { name: /Projects/ }));
    await screen.findByText("Customer Portal Redesign");

    // prj-1 began on 2026-06-01; prj-2 begins on 2026-11-03.
    expect(screen.getByText("Started")).toBeInTheDocument();
    expect(screen.getByText("Upcoming")).toBeInTheDocument();
  });

  it("counts the rows behind each tab", async () => {
    render(<App client={createFakeClient()} />);
    await screen.findByText("Maria Santos");

    const directoryTab = screen.getByRole("tab", { name: /Employee Directory/ });
    expect(directoryTab).toHaveTextContent("3");
  });
});

describe("when the API cannot be reached", () => {
  it("says so instead of showing an empty directory", async () => {
    const client = createFakeClient({
      getEmployees: async () => {
        throw new ApiError("Cannot reach the API at http://localhost:4000.", { status: 0 });
      },
    });

    render(<App client={client} />);

    expect(await screen.findByText("Could not load the data")).toBeInTheDocument();
    expect(screen.getByText("Cannot reach the API at http://localhost:4000.")).toBeInTheDocument();
  });

  it("offers to try again", async () => {
    let attempts = 0;
    const working = createFakeClient();
    const client = createFakeClient({
      getEmployees: async () => {
        attempts += 1;
        if (attempts === 1) throw new ApiError("Cannot reach the API.", { status: 0 });
        return working.getEmployees();
      },
    });

    render(<App client={client} />);
    await screen.findByText("Could not load the data");

    fireEvent.click(screen.getByRole("button", { name: "Try again" }));

    expect(await screen.findByText("Maria Santos")).toBeInTheDocument();
    await waitFor(() =>
      expect(screen.queryByText("Could not load the data")).not.toBeInTheDocument(),
    );
  });
});

describe("demo mode", () => {
  it("warns that changes are not saved when there is no backend", async () => {
    render(<App client={createFakeClient({ isDemo: true })} />);

    expect(await screen.findByText("Demo mode")).toBeInTheDocument();
  });

  it("shows no such banner when talking to the real API", async () => {
    render(<App client={createFakeClient()} />);

    await screen.findByText("Maria Santos");
    expect(screen.queryByText("Demo mode")).not.toBeInTheDocument();
  });
});
