/**
 * Tests for the New Project form.
 *
 * REQUIREMENT: create a project with a name, description, employees, complexity
 * and start date.
 * LOGIC CHECK: a project must have at least one employee, and warnings appear
 * without blocking the save.
 */

import { describe, it, expect, vi } from "vitest";
import { render, screen, fireEvent, waitFor } from "@testing-library/react";

import NewProjectForm from "../components/NewProjectForm.jsx";
import { createFakeClient, EMPLOYEES, PROJECTS, TODAY, validationError } from "./fixtures.js";

function renderForm(props = {}) {
  const client = props.client ?? createFakeClient();
  const onCreated = props.onCreated ?? vi.fn();
  const onClose = props.onClose ?? vi.fn();

  render(
    <NewProjectForm
      client={client}
      employees={EMPLOYEES}
      projects={PROJECTS}
      today={TODAY}
      onClose={onClose}
      onCreated={onCreated}
      {...props}
    />,
  );

  return { client, onCreated, onClose };
}

/** Fills in everything except the employees. */
function fillTextFields({ name = "Internal API Gateway", startDate = "2026-12-01" } = {}) {
  fireEvent.change(screen.getByLabelText(/Project name/), { target: { value: name } });
  fireEvent.change(screen.getByLabelText(/Description/), {
    target: { value: "Put internal traffic behind one gateway." },
  });
  fireEvent.change(screen.getByLabelText(/Start date/), { target: { value: startDate } });
}

describe("required fields", () => {
  it("reports every empty field on submit", () => {
    renderForm();

    fireEvent.click(screen.getByRole("button", { name: "Create project" }));

    expect(screen.getByText("Project name is required.")).toBeInTheDocument();
    expect(screen.getByText("Description is required.")).toBeInTheDocument();
    expect(screen.getByText("Start date is required.")).toBeInTheDocument();
  });

  it("LOGIC CHECK: refuses a project with no employees", () => {
    renderForm();

    fillTextFields();
    fireEvent.click(screen.getByRole("button", { name: "Create project" }));

    expect(screen.getByText("Assign at least one employee to this project.")).toBeInTheDocument();
  });

  it("does not call the API while the form is invalid", () => {
    const createProject = vi.fn();
    renderForm({ client: { ...createFakeClient(), createProject } });

    fillTextFields();
    fireEvent.click(screen.getByRole("button", { name: "Create project" }));

    expect(createProject).not.toHaveBeenCalled();
  });
});

describe("choosing employees", () => {
  it("counts how many are selected", () => {
    renderForm();

    expect(screen.getByText("Choose at least one person to work on this.")).toBeInTheDocument();

    fireEvent.click(screen.getByRole("checkbox", { name: /Maria Santos/ }));

    expect(screen.getByText("1 selected")).toBeInTheDocument();
  });

  it("can be searched, so a long list stays usable", () => {
    renderForm();

    fireEvent.change(screen.getByLabelText("Search employees to assign"), {
      target: { value: "paolo" },
    });

    expect(screen.getByRole("checkbox", { name: /Paolo Reyes/ })).toBeInTheDocument();
    expect(screen.queryByRole("checkbox", { name: /Maria Santos/ })).not.toBeInTheDocument();
  });

  it("clears the error once someone is chosen", () => {
    renderForm();

    fillTextFields();
    fireEvent.click(screen.getByRole("button", { name: "Create project" }));
    expect(screen.getByText("Assign at least one employee to this project.")).toBeInTheDocument();

    fireEvent.click(screen.getByRole("checkbox", { name: /Maria Santos/ }));

    expect(
      screen.queryByText("Assign at least one employee to this project."),
    ).not.toBeInTheDocument();
  });
});

describe("warnings", () => {
  it("LOGIC CHECK: warns about a start date in the past but still allows saving", () => {
    renderForm();

    fillTextFields({ startDate: "2026-01-05" });

    expect(screen.getByText(/will show as already started/)).toBeInTheDocument();
    expect(screen.getByRole("button", { name: "Create project" })).not.toBeDisabled();
  });

  it("warns when another project already has the name", () => {
    renderForm();

    fillTextFields({ name: "Customer Portal Redesign" });

    expect(screen.getByText("Another project already has this name.")).toBeInTheDocument();
  });
});

describe("saving", () => {
  it("REQUIREMENT: sends every field to the API", async () => {
    const createProject = vi.fn(async (payload) => ({ id: "prj-99", ...payload, warnings: [] }));
    const { onCreated } = renderForm({ client: { ...createFakeClient(), createProject } });

    fillTextFields();
    fireEvent.click(screen.getByRole("checkbox", { name: /Maria Santos/ }));
    fireEvent.click(screen.getByRole("radio", { name: /High/i }));
    fireEvent.click(screen.getByRole("button", { name: "Create project" }));

    await waitFor(() => expect(createProject).toHaveBeenCalledTimes(1));

    expect(createProject).toHaveBeenCalledWith({
      name: "Internal API Gateway",
      description: "Put internal traffic behind one gateway.",
      employeeIds: ["emp-1"],
      complexity: "high",
      startDate: "2026-12-01",
    });
    await waitFor(() => expect(onCreated).toHaveBeenCalled());
  });

  it("shows the server's own message when it refuses the project", async () => {
    const createProject = vi.fn(async () => {
      // The server is the authority: it rejects even if the browser was happy.
      throw validationError({ employeeIds: "These employees no longer exist: emp-1." });
    });
    renderForm({ client: { ...createFakeClient(), createProject } });

    fillTextFields();
    fireEvent.click(screen.getByRole("checkbox", { name: /Maria Santos/ }));
    fireEvent.click(screen.getByRole("button", { name: "Create project" }));

    expect(
      await screen.findByText("These employees no longer exist: emp-1."),
    ).toBeInTheDocument();
  });
});
