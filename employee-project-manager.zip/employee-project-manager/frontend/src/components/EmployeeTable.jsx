/**
 * EmployeeTable.jsx — the employee list.
 *
 * REQUIREMENT: "Display a comprehensive list of employees", plus the buttons
 * that open the details pop-up and start a delete.
 */

import Button from "./Button.jsx";
import { fullName } from "../lib/filters.js";

/** The circle of initials shown beside each name. */
function Avatar({ employee }) {
  const initials = `${employee.firstName?.[0] ?? ""}${employee.lastName?.[0] ?? ""}`.toUpperCase();

  return (
    <span
      aria-hidden="true"
      className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-brand-100 text-xs font-semibold text-brand-700"
    >
      {initials}
    </span>
  );
}

export default function EmployeeTable({ employees, onView, onDelete, busyId }) {
  // Nothing matched the search or the filter.
  if (employees.length === 0) {
    return (
      <div className="rounded-xl border border-dashed border-slate-300 bg-white px-6 py-12 text-center">
        <p className="text-sm font-medium text-slate-900">No employees match your search.</p>
        <p className="mt-1 text-sm text-slate-500">
          Try a different name, or set the department filter back to All.
        </p>
      </div>
    );
  }

  return (
    <div className="overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm">
      {/* Scrolls sideways on a narrow screen rather than squashing the columns. */}
      <div className="overflow-x-auto">
        <table className="w-full text-left text-sm">
          <caption className="sr-only-label">
            Employees, with their position, department and email
          </caption>

          <thead className="border-b border-slate-200 bg-slate-50 text-xs tracking-wide text-slate-500 uppercase">
            <tr>
              <th scope="col" className="px-4 py-3 font-semibold">
                Name
              </th>
              <th scope="col" className="hidden px-4 py-3 font-semibold sm:table-cell">
                Position
              </th>
              <th scope="col" className="px-4 py-3 font-semibold">
                Department
              </th>
              <th scope="col" className="hidden px-4 py-3 font-semibold lg:table-cell">
                Email
              </th>
              <th scope="col" className="px-4 py-3 text-right font-semibold">
                <span className="sr-only-label">Actions</span>
              </th>
            </tr>
          </thead>

          <tbody className="divide-y divide-slate-100">
            {employees.map((employee) => (
              <tr key={employee.id} className="transition hover:bg-slate-50">
                <th scope="row" className="px-4 py-3 font-normal">
                  <div className="flex items-center gap-3">
                    <Avatar employee={employee} />
                    <div className="min-w-0">
                      <p className="truncate font-medium text-slate-900">{fullName(employee)}</p>
                      {/* On small screens the position column is hidden, so show it here. */}
                      <p className="truncate text-xs text-slate-500 sm:hidden">
                        {employee.position}
                      </p>
                    </div>
                  </div>
                </th>

                <td className="hidden px-4 py-3 text-slate-600 sm:table-cell">
                  {employee.position}
                </td>

                <td className="px-4 py-3">
                  <span className="inline-flex rounded-md bg-slate-100 px-2 py-1 text-xs font-medium text-slate-700">
                    {employee.department}
                  </span>
                </td>

                <td className="hidden px-4 py-3 text-slate-600 lg:table-cell">
                  <a
                    href={`mailto:${employee.email}`}
                    className="hover:text-brand-600 hover:underline"
                  >
                    {employee.email}
                  </a>
                </td>

                <td className="px-4 py-3">
                  <div className="flex justify-end gap-2">
                    {/* REQUIREMENT: view individual employee details. */}
                    <Button
                      variant="secondary"
                      onClick={() => onView(employee)}
                      aria-label={`View details for ${fullName(employee)}`}
                      className="px-3 py-1.5"
                    >
                      View
                    </Button>

                    {/* REQUIREMENT: delete an employee. Asks for confirmation first. */}
                    <Button
                      variant="ghost"
                      onClick={() => onDelete(employee)}
                      busy={busyId === employee.id}
                      busyLabel="…"
                      aria-label={`Delete ${fullName(employee)}`}
                      className="px-3 py-1.5 text-red-600 hover:bg-red-50"
                    >
                      Delete
                    </Button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
