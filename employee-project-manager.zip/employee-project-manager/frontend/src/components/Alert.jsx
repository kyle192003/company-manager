/**
 * Alert.jsx — the banner used for errors, warnings and confirmations.
 *
 * LOGIC CHECK: "UI must show error messages/warnings." This is the component
 * every screen uses to do that.
 *
 * `role="alert"` makes a screen reader announce the message as soon as it appears.
 */

const TONES = {
  error: {
    box: "bg-red-50 border-red-200 text-red-800",
    icon: "✕",
    label: "Error",
  },
  warning: {
    box: "bg-amber-50 border-amber-200 text-amber-900",
    icon: "!",
    label: "Warning",
  },
  success: {
    box: "bg-emerald-50 border-emerald-200 text-emerald-800",
    icon: "✓",
    label: "Success",
  },
  info: {
    box: "bg-brand-50 border-brand-200 text-brand-700",
    icon: "i",
    label: "Note",
  },
};

export default function Alert({ tone = "error", title, children, onDismiss }) {
  const style = TONES[tone] ?? TONES.error;

  return (
    <div
      // Errors interrupt; warnings and notes wait for a pause in speech.
      role={tone === "error" ? "alert" : "status"}
      className={`flex items-start gap-3 rounded-lg border px-4 py-3 text-sm ${style.box}`}
    >
      <span
        aria-hidden="true"
        className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-white/70 text-xs font-bold"
      >
        {style.icon}
      </span>

      <div className="min-w-0 flex-1">
        {title && <p className="font-semibold">{title}</p>}
        <div className={title ? "mt-0.5" : ""}>{children}</div>
      </div>

      {onDismiss && (
        <button
          type="button"
          onClick={onDismiss}
          className="shrink-0 rounded px-1 text-lg leading-none opacity-60 transition hover:opacity-100 focus:outline-none focus-visible:ring-2 focus-visible:ring-current"
          aria-label="Dismiss message"
        >
          ×
        </button>
      )}
    </div>
  );
}
