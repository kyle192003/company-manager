/**
 * Field.jsx — one labelled form input, with its error message underneath.
 *
 * LOGIC CHECK: "UI must show error messages/warnings."
 * Wrapping this up once means every field in both forms reports problems the
 * same way, and correctly for screen readers: the input is marked invalid and
 * pointed at its message with aria-describedby.
 */

/** Shared input styling, so every control matches. */
export const inputClasses =
  "w-full rounded-lg border px-3 py-2 text-sm text-slate-900 shadow-sm transition " +
  "placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-brand-500 focus:border-brand-500";

/** Red border when a field has a problem, grey otherwise. */
export function borderFor(error) {
  return error ? "border-red-400 bg-red-50/40" : "border-slate-300 bg-white";
}

export default function Field({ id, label, error, hint, required, children }) {
  const errorId = `${id}-error`;
  const hintId = `${id}-hint`;

  return (
    <div>
      <label htmlFor={id} className="block text-sm font-medium text-slate-700">
        {label}
        {required && (
          <span className="ml-0.5 text-red-500" aria-hidden="true">
            *
          </span>
        )}
      </label>

      <div className="mt-1.5">
        {/*
          The screen passes the actual input as a function so it can receive the
          ids and styling worked out here.
        */}
        {children({
          id,
          className: `${inputClasses} ${borderFor(error)}`,
          "aria-invalid": error ? true : undefined,
          "aria-describedby": error ? errorId : hint ? hintId : undefined,
          "aria-required": required || undefined,
        })}
      </div>

      {hint && !error && (
        <p id={hintId} className="mt-1 text-xs text-slate-500">
          {hint}
        </p>
      )}

      {error && (
        <p id={errorId} className="mt-1 text-xs font-medium text-red-600">
          {error}
        </p>
      )}
    </div>
  );
}
