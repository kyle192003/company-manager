/**
 * Button.jsx — one button component in three styles, so every screen matches.
 *
 *   primary  — the main action (Add employee, Create project)
 *   secondary— Cancel, and anything that steps back
 *   danger   — Delete
 */

const BASE =
  "inline-flex items-center justify-center gap-2 rounded-lg px-4 py-2 text-sm font-medium " +
  "transition focus:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 " +
  "disabled:cursor-not-allowed disabled:opacity-60";

const VARIANTS = {
  primary: "bg-brand-600 text-white shadow-sm hover:bg-brand-700 focus-visible:ring-brand-500",
  secondary:
    "border border-slate-300 bg-white text-slate-700 shadow-sm hover:bg-slate-50 focus-visible:ring-brand-500",
  danger: "bg-red-600 text-white shadow-sm hover:bg-red-700 focus-visible:ring-red-500",
  ghost: "text-slate-600 hover:bg-slate-100 focus-visible:ring-brand-500",
};

export default function Button({
  variant = "primary",
  type = "button",
  busy = false,
  busyLabel = "Working…",
  children,
  className = "",
  ...rest
}) {
  return (
    <button
      type={type}
      // A busy button must not be clickable twice.
      disabled={busy || rest.disabled}
      className={`${BASE} ${VARIANTS[variant] ?? VARIANTS.primary} ${className}`}
      {...rest}
    >
      {busy ? busyLabel : children}
    </button>
  );
}
