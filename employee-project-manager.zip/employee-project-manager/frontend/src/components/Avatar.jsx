/**
 * Avatar.jsx — an employee's photo, with their initials as the fallback.
 *
 * The picture is never allowed to be the difference between a usable directory
 * and a broken one. If an employee has no photo, or the file 404s, or the
 * network blocks it, the coloured initials appear instead and the layout does
 * not move.
 *
 * The seeded employees use the illustrated SVGs in public/avatars/, generated
 * by scripts/generate-avatars.mjs. A real photo URL works just as well.
 */

import { useState } from "react";

import { fullName } from "../lib/filters.js";

/** Pixel size for each of the sizes the app uses. */
const SIZES = {
  xs: "h-5 w-5 text-[9px]",
  sm: "h-9 w-9 text-xs",
  md: "h-12 w-12 text-sm",
  lg: "h-20 w-20 text-xl",
};

/**
 * Works out the real src for a photo.
 *
 * Stored paths are relative ("avatars/emp-1.svg") because the app is served
 * from "/" locally but from "/<repository-name>/" on GitHub Pages. BASE_URL
 * holds whichever it is. A full http(s) URL is left alone.
 */
export function resolvePhotoUrl(photoUrl) {
  if (!photoUrl) return "";
  if (/^https?:\/\//i.test(photoUrl)) return photoUrl;

  const base = import.meta.env?.BASE_URL ?? "/";
  return `${base.replace(/\/$/, "")}/${photoUrl.replace(/^\//, "")}`;
}

/** "Maria Santos" → "MS" */
function initialsOf(employee) {
  return `${employee?.firstName?.[0] ?? ""}${employee?.lastName?.[0] ?? ""}`.toUpperCase();
}

export default function Avatar({ employee, size = "sm" }) {
  // Flipped to true if the image fails, which swaps in the initials for good.
  const [failed, setFailed] = useState(false);

  const source = resolvePhotoUrl(employee?.photoUrl);
  const sizeClasses = SIZES[size] ?? SIZES.sm;
  const showPhoto = source && !failed;

  if (showPhoto) {
    return (
      <img
        src={source}
        // The name is already beside the picture in every place this is used,
        // so an alt would just repeat it. Empty alt hides it from screen
        // readers instead of reading the name twice.
        alt=""
        // Marks the photo as decoration, alongside the empty alt.
        aria-hidden="true"
        onError={() => setFailed(true)}
        // Stops the row from jumping while the image loads.
        width={80}
        height={80}
        className={`${sizeClasses} shrink-0 rounded-full bg-slate-100 object-cover ring-1 ring-slate-200`}
      />
    );
  }

  return (
    <span
      aria-hidden="true"
      title={employee ? fullName(employee) : undefined}
      className={`${sizeClasses} flex shrink-0 items-center justify-center rounded-full bg-brand-100 font-semibold text-brand-700 ring-1 ring-brand-200`}
    >
      {initialsOf(employee)}
    </span>
  );
}
