/**
 * Modal.jsx — the pop-up used for employee details and for both forms.
 *
 * Keeping these as pop-ups is what lets the whole app live on the two screens
 * the brief asks for: the directory and the project list are the only pages, and
 * everything else opens on top of them.
 *
 * Behaviour handled here so no screen has to repeat it:
 *   - Escape closes it
 *   - clicking the dark backdrop closes it
 *   - the page behind does not scroll while it is open
 *   - focus moves into the dialog when it opens
 */

import { useEffect, useRef } from "react";

export default function Modal({ title, description, onClose, children, footer, size = "md" }) {
  const dialogRef = useRef(null);

  useEffect(() => {
    /** Escape is the expected way out of any dialog. */
    function handleKeyDown(event) {
      if (event.key === "Escape") onClose();
    }

    document.addEventListener("keydown", handleKeyDown);

    // Stop the page behind from scrolling under the dialog.
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";

    // Move focus into the dialog so keyboard users are not left behind it.
    dialogRef.current?.focus();

    return () => {
      document.removeEventListener("keydown", handleKeyDown);
      document.body.style.overflow = previousOverflow;
    };
  }, [onClose]);

  const widths = { md: "max-w-lg", lg: "max-w-2xl" };

  return (
    // The backdrop. Clicking it closes the dialog.
    <div
      className="fixed inset-0 z-50 flex items-end justify-center bg-slate-900/50 p-0 sm:items-center sm:p-4"
      onMouseDown={(event) => {
        // Only a click on the backdrop itself counts, not one that started inside.
        if (event.target === event.currentTarget) onClose();
      }}
    >
      <div
        ref={dialogRef}
        role="dialog"
        aria-modal="true"
        aria-labelledby="modal-title"
        tabIndex={-1}
        className={`flex max-h-[92vh] w-full flex-col rounded-t-2xl bg-white shadow-xl outline-none sm:rounded-2xl ${widths[size] ?? widths.md}`}
      >
        <header className="flex items-start justify-between gap-4 border-b border-slate-200 px-6 py-4">
          <div className="min-w-0">
            <h2 id="modal-title" className="text-lg font-semibold text-slate-900">
              {title}
            </h2>
            {description && <p className="mt-0.5 text-sm text-slate-500">{description}</p>}
          </div>

          <button
            type="button"
            onClick={onClose}
            aria-label="Close"
            className="-mr-2 -mt-1 shrink-0 rounded-lg px-2 py-1 text-2xl leading-none text-slate-400 transition hover:bg-slate-100 hover:text-slate-600 focus:outline-none focus-visible:ring-2 focus-visible:ring-brand-500"
          >
            ×
          </button>
        </header>

        {/* The scrolling middle, so a long form never pushes the buttons off screen. */}
        <div className="min-h-0 flex-1 overflow-y-auto px-6 py-5">{children}</div>

        {footer && (
          <footer className="flex flex-wrap justify-end gap-3 border-t border-slate-200 px-6 py-4">
            {footer}
          </footer>
        )}
      </div>
    </div>
  );
}
