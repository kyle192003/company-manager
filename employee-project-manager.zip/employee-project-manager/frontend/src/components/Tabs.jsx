/**
 * Tabs.jsx — the switcher between the two screens.
 *
 * The app is one page with two views: the Employee Directory and Projects.
 * This is the control that swaps between them.
 *
 * It follows the standard tab pattern, so the arrow keys move between tabs and a
 * screen reader announces which one is selected.
 */

export default function Tabs({ tabs, activeId, onChange }) {
  /**
   * Arrow keys move between tabs, Home and End jump to the ends.
   * Focus follows the selection, because only the selected tab is in the tab
   * order — leaving focus on the old one would strand the keyboard.
   */
  function handleKeyDown(event) {
    const index = tabs.findIndex((tab) => tab.id === activeId);
    let nextIndex = null;

    if (event.key === "ArrowRight") nextIndex = (index + 1) % tabs.length;
    else if (event.key === "ArrowLeft") nextIndex = (index - 1 + tabs.length) % tabs.length;
    else if (event.key === "Home") nextIndex = 0;
    else if (event.key === "End") nextIndex = tabs.length - 1;

    if (nextIndex === null) return;

    event.preventDefault();
    const nextTab = tabs[nextIndex];
    onChange(nextTab.id);
    event.currentTarget.querySelector(`#tab-${nextTab.id}`)?.focus();
  }

  return (
    <div
      role="tablist"
      aria-label="Screens"
      onKeyDown={handleKeyDown}
      className="inline-flex rounded-xl border border-slate-200 bg-white p-1 shadow-sm"
    >
      {tabs.map((tab) => {
        const isActive = tab.id === activeId;

        return (
          <button
            key={tab.id}
            role="tab"
            id={`tab-${tab.id}`}
            aria-selected={isActive}
            aria-controls={`panel-${tab.id}`}
            // Only the selected tab is in the tab order; arrows reach the others.
            tabIndex={isActive ? 0 : -1}
            onClick={() => onChange(tab.id)}
            className={`flex items-center gap-2 rounded-lg px-4 py-2 text-sm font-medium transition focus:outline-none focus-visible:ring-2 focus-visible:ring-brand-500 ${
              isActive
                ? "bg-brand-600 text-white shadow-sm"
                : "text-slate-600 hover:bg-slate-100 hover:text-slate-900"
            }`}
          >
            {tab.label}

            {/* The count of rows behind each tab, e.g. "12". */}
            {typeof tab.count === "number" && (
              <span
                className={`rounded-full px-2 py-0.5 text-xs font-semibold ${
                  isActive ? "bg-white/20 text-white" : "bg-slate-100 text-slate-600"
                }`}
              >
                {tab.count}
              </span>
            )}
          </button>
        );
      })}
    </div>
  );
}
