/**
 * AddEmployeeForm.jsx — the Add Employee pop-up.
 *
 * REQUIREMENT: "Add an Employee."
 * LOGIC CHECK: "UI must show error messages/warnings."
 *
 * The form checks itself before sending anything, so mistakes are pointed out
 * immediately. The server checks again and its messages are merged into the same
 * per-field display, which is how a duplicate email created in another tab
 * still lands on the email field.
 */

import { useState } from "react";

import Modal from "./Modal.jsx";
import Button from "./Button.jsx";
import Alert from "./Alert.jsx";
import Field, { inputClasses, borderFor } from "./Field.jsx";
import { validateEmployee, isValid } from "../lib/validation.js";

/** An empty form. */
const BLANK = {
  firstName: "",
  lastName: "",
  email: "",
  position: "",
  department: "",
  hireDate: "",
};

export default function AddEmployeeForm({ client, employees, departments, onClose, onCreated }) {
  const [values, setValues] = useState(BLANK);
  const [errors, setErrors] = useState({});
  const [formError, setFormError] = useState("");
  const [saving, setSaving] = useState(false);
  // Fields the user has finished with. Errors only appear once a field has been
  // left, so the form does not shout while it is still being filled in.
  const [touched, setTouched] = useState({});

  /** Live validation result, used to mark fields as the user goes. */
  const liveErrors = validateEmployee(values, { employees, departments });

  /** Shows an error only if the field was touched, or the form was submitted. */
  function errorFor(field) {
    return errors[field] ?? (touched[field] ? liveErrors[field] : undefined);
  }

  function update(field, value) {
    setValues((current) => ({ ...current, [field]: value }));
    // Clear the server's message for this field as soon as it is edited.
    setErrors((current) => {
      if (!current[field]) return current;
      const next = { ...current };
      delete next[field];
      return next;
    });
  }

  function markTouched(field) {
    setTouched((current) => ({ ...current, [field]: true }));
  }

  async function handleSubmit(event) {
    event.preventDefault();
    setFormError("");

    // Check everything in the browser first.
    const found = validateEmployee(values, { employees, departments });
    if (!isValid(found)) {
      setErrors(found);
      // Reveal every message at once, including for untouched fields.
      setTouched(Object.fromEntries(Object.keys(BLANK).map((field) => [field, true])));
      return;
    }

    setSaving(true);
    try {
      const created = await client.createEmployee(values);
      onCreated(created);
    } catch (problem) {
      // The server refused it: show its field messages, or its general one.
      setErrors(problem.errors ?? {});
      setFormError(Object.keys(problem.errors ?? {}).length > 0 ? "" : problem.message);
      setTouched(Object.fromEntries(Object.keys(BLANK).map((field) => [field, true])));
    } finally {
      setSaving(false);
    }
  }

  return (
    <Modal
      title="Add an employee"
      description="They can be assigned to projects as soon as they are saved."
      onClose={onClose}
      footer={
        <>
          <Button variant="secondary" onClick={onClose} disabled={saving}>
            Cancel
          </Button>
          <Button type="submit" form="add-employee-form" busy={saving} busyLabel="Saving…">
            Save employee
          </Button>
        </>
      }
    >
      <form id="add-employee-form" onSubmit={handleSubmit} noValidate className="space-y-4">
        {formError && <Alert tone="error">{formError}</Alert>}

        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <Field id="firstName" label="First name" required error={errorFor("firstName")}>
            {(props) => (
              <input
                {...props}
                value={values.firstName}
                onChange={(event) => update("firstName", event.target.value)}
                onBlur={() => markTouched("firstName")}
                placeholder="Maria"
                autoComplete="given-name"
              />
            )}
          </Field>

          <Field id="lastName" label="Last name" required error={errorFor("lastName")}>
            {(props) => (
              <input
                {...props}
                value={values.lastName}
                onChange={(event) => update("lastName", event.target.value)}
                onBlur={() => markTouched("lastName")}
                placeholder="Santos"
                autoComplete="family-name"
              />
            )}
          </Field>
        </div>

        <Field
          id="email"
          label="Email"
          required
          error={errorFor("email")}
          hint="Must be unique across the directory."
        >
          {(props) => (
            <input
              {...props}
              type="email"
              value={values.email}
              onChange={(event) => update("email", event.target.value)}
              onBlur={() => markTouched("email")}
              placeholder="maria.santos@example.com"
              autoComplete="email"
            />
          )}
        </Field>

        <Field id="position" label="Position" required error={errorFor("position")}>
          {(props) => (
            <input
              {...props}
              value={values.position}
              onChange={(event) => update("position", event.target.value)}
              onBlur={() => markTouched("position")}
              placeholder="Senior Software Engineer"
            />
          )}
        </Field>

        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <Field id="department" label="Department" required error={errorFor("department")}>
            {(props) => (
              <select
                {...props}
                value={values.department}
                onChange={(event) => update("department", event.target.value)}
                onBlur={() => markTouched("department")}
              >
                <option value="">Choose a department…</option>
                {departments.map((department) => (
                  <option key={department} value={department}>
                    {department}
                  </option>
                ))}
              </select>
            )}
          </Field>

          <Field
            id="hireDate"
            label="Hire date"
            error={errorFor("hireDate")}
            hint="Optional — today is used if left blank."
          >
            {(props) => (
              <input
                {...props}
                type="date"
                value={values.hireDate}
                onChange={(event) => update("hireDate", event.target.value)}
                onBlur={() => markTouched("hireDate")}
                className={`${inputClasses} ${borderFor(errorFor("hireDate"))}`}
              />
            )}
          </Field>
        </div>
      </form>
    </Modal>
  );
}
