/**
 * SearchField.jsx — the search box used on both screens.
 *
 * REQUIREMENT: "Search Employees by Name" and "Search Projects by Name".
 *
 * It filters as you type. There is no Search button and no waiting, because the
 * list is already loaded and filtering happens in the browser.
 */

export default function SearchField({ id, label, value, onChange, placeholder, resultCount }) {
  return (
    <div className="relative flex-1">
      {/* Visible text would repeat the placeholder, so the label is for screen readers. */}
      <label htmlFor={id} className="sr-only-label">
        {label}
      </label>

      <span
        aria-hidden="true"
        className="pointer-events-none absolute top-1/2 left-3 -translate-y-1/2 text-slate-400"
      >
        ⌕
      </span>

      <input
        id={id}
        type="search"
        value={value}
        placeholder={placeholder}
        onChange={(event) => onChange(event.target.value)}
        className="w-full rounded-lg border border-slate-300 bg-white py-2 pr-3 pl-9 text-sm text-slate-900 shadow-sm transition placeholder:text-slate-400 focus:border-brand-500 focus:ring-2 focus:ring-brand-500 focus:outline-none"
      />

      {/*
        Announces "3 results" as the list changes, so someone using a screen
        reader hears the effect of their typing. aria-live waits for a pause.
      */}
      <span aria-live="polite" className="sr-only-label">
        {resultCount} {resultCount === 1 ? "result" : "results"}
      </span>
    </div>
  );
}
