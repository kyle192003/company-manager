/**
 * ProjectCard.jsx — one project in the Projects screen.
 *
 * LOGIC CHECK: "UI must indicate if a project has already started based on the
 * start date." The badge in the corner and the line under the dates both come
 * from describeStart().
 */

import { StatusBadge, ComplexityBadge } from "./Badge.jsx";
import Avatar from "./Avatar.jsx";
import { describeStart, formatDate } from "../lib/dates.js";
import { fullName } from "../lib/filters.js";

export default function ProjectCard({ project, today }) {
  const status = describeStart(project.startDate, today);
  const members = project.employees ?? [];

  return (
    <article
      className={`flex flex-col rounded-xl border bg-white p-5 shadow-sm transition hover:shadow-md ${
        // A subtle left edge repeats the status for anyone scanning quickly.
        status.started ? "border-slate-200 border-l-4 border-l-emerald-400" : "border-slate-200 border-l-4 border-l-amber-400"
      }`}
    >
      <header className="flex items-start justify-between gap-3">
        <h3 className="text-base font-semibold text-slate-900">{project.name}</h3>
        <StatusBadge status={status} />
      </header>

      <p className="mt-2 flex-1 text-sm leading-relaxed text-slate-600">{project.description}</p>

      <div className="mt-4 flex flex-wrap items-center gap-2">
        <ComplexityBadge complexity={project.complexity} />
      </div>

      <dl className="mt-4 grid grid-cols-2 gap-3 border-t border-slate-100 pt-4 text-sm">
        <div>
          <dt className="text-xs font-medium tracking-wide text-slate-500 uppercase">
            Start date
          </dt>
          <dd className="mt-0.5 text-slate-900">{formatDate(project.startDate)}</dd>
        </div>
        <div>
          <dt className="text-xs font-medium tracking-wide text-slate-500 uppercase">Status</dt>
          <dd className={`mt-0.5 ${status.started ? "text-emerald-700" : "text-amber-700"}`}>
            {status.label}
          </dd>
        </div>
      </dl>

      <div className="mt-4 border-t border-slate-100 pt-4">
        <p className="text-xs font-medium tracking-wide text-slate-500 uppercase">
          Team ({members.length})
        </p>

        <ul className="mt-2 flex flex-wrap gap-1.5">
          {members.map((employee) => (
            <li
              key={employee.id}
              className="flex items-center gap-1.5 rounded-full bg-slate-100 py-1 pr-2.5 pl-1 text-xs text-slate-700"
              title={`${employee.position} · ${employee.department}`}
            >
              <Avatar employee={employee} size="xs" />
              {fullName(employee)}
            </li>
          ))}
        </ul>
      </div>
    </article>
  );
}
