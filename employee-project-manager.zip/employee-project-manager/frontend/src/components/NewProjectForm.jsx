/**
 * NewProjectForm.jsx — the New Project pop-up.
 *
 * REQUIREMENT: "Create new projects with Project Name, Description, Employees
 * (must include at least one existing employee), Project Complexity
 * (low, medium, high) and Start Date."
 *
 * LOGIC CHECK: a project must have at least one employee — the employee picker
 * refuses to submit without one, and the server refuses it again.
 * LOGIC CHECK: warnings (a start date in the past, a name already in use) are
 * shown without blocking the save.
 */

import { useState } from "react";

import Modal from "./Modal.jsx";
import Button from "./Button.jsx";
import Alert from "./Alert.jsx";
import Field, { inputClasses, borderFor } from "./Field.jsx";
import Avatar from "./Avatar.jsx";
import { COMPLEXITY_LEVELS, validateProject, getProjectWarnings, isValid } from "../lib/validation.js";
import { filterEmployees, fullName, sortEmployees } from "../lib/filters.js";

/** An empty form. Medium is pre-selected because it is the common case. */
const BLANK = {
  name: "",
  description: "",
  employeeIds: [],
  complexity: "medium",
  startDate: "",
};

/** How each complexity level is described in the picker. */
const COMPLEXITY_HINTS = {
  low: "Small, well understood",
  medium: "Normal scope",
  high: "Large or uncertain",
};

export default function NewProjectForm({ client, employees, projects, onClose, onCreated, today }) {
  const [values, setValues] = useState(BLANK);
  const [errors, setErrors] = useState({});
  const [formError, setFormError] = useState("");
  const [saving, setSaving] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  // Search inside the employee picker — separate from the screen's own search.
  const [employeeSearch, setEmployeeSearch] = useState("");

  const liveErrors = validateProject(values, { employees });
  // Warnings are advisory, so they can show as soon as there is something to say.
  const warnings = getProjectWarnings(values, { projects, now: today });

  /** Server errors win; the browser's own appear once the form is submitted. */
  function errorFor(field) {
    return errors[field] ?? (submitted ? liveErrors[field] : undefined);
  }

  function update(field, value) {
    setValues((current) => ({ ...current, [field]: value }));
    setErrors((current) => {
      if (!current[field]) return current;
      const next = { ...current };
      delete next[field];
      return next;
    });
  }

  /** Adds or removes one employee from the project. */
  function toggleEmployee(id) {
    update(
      "employeeIds",
      values.employeeIds.includes(id)
        ? values.employeeIds.filter((current) => current !== id)
        : [...values.employeeIds, id],
    );
  }

  async function handleSubmit(event) {
    event.preventDefault();
    setSubmitted(true);
    setFormError("");

    const found = validateProject(values, { employees });
    if (!isValid(found)) {
      setErrors(found);
      return;
    }

    setSaving(true);
    try {
      const created = await client.createProject(values);
      onCreated(created);
    } catch (problem) {
      setErrors(problem.errors ?? {});
      setFormError(Object.keys(problem.errors ?? {}).length > 0 ? "" : problem.message);
    } finally {
      setSaving(false);
    }
  }

  // The employee picker's own filtered list.
  const pickerEmployees = sortEmployees(filterEmployees(employees, { search: employeeSearch }));
  const employeeError = errorFor("employeeIds");

  return (
    <Modal
      title="New project"
      description="Every project needs at least one employee."
      onClose={onClose}
      size="lg"
      footer={
        <>
          <Button variant="secondary" onClick={onClose} disabled={saving}>
            Cancel
          </Button>
          <Button type="submit" form="new-project-form" busy={saving} busyLabel="Creating…">
            Create project
          </Button>
        </>
      }
    >
      <form id="new-project-form" onSubmit={handleSubmit} noValidate className="space-y-5">
        {formError && <Alert tone="error">{formError}</Alert>}

        <Field id="name" label="Project name" required error={errorFor("name")}>
          {(props) => (
            <input
              {...props}
              value={values.name}
              onChange={(event) => update("name", event.target.value)}
              placeholder="Customer Portal Redesign"
            />
          )}
        </Field>

        <Field id="description" label="Description" required error={errorFor("description")}>
          {(props) => (
            <textarea
              {...props}
              rows={3}
              value={values.description}
              onChange={(event) => update("description", event.target.value)}
              placeholder="What this project sets out to do."
              className={`${inputClasses} ${borderFor(errorFor("description"))} resize-y`}
            />
          )}
        </Field>

        {/* --- Employees: the "at least one" rule lives here --- */}
        <fieldset>
          <legend className="text-sm font-medium text-slate-700">
            Employees
            <span className="ml-0.5 text-red-500" aria-hidden="true">
              *
            </span>
          </legend>

          <p className="mt-1 text-xs text-slate-500">
            {values.employeeIds.length === 0
              ? "Choose at least one person to work on this."
              : `${values.employeeIds.length} selected`}
          </p>

          <div
            className={`mt-2 overflow-hidden rounded-lg border ${borderFor(employeeError)}`}
          >
            <div className="border-b border-slate-200 bg-slate-50 p-2">
              <label htmlFor="employee-picker-search" className="sr-only-label">
                Search employees to assign
              </label>
              <input
                id="employee-picker-search"
                type="search"
                value={employeeSearch}
                onChange={(event) => setEmployeeSearch(event.target.value)}
                placeholder="Search people by name…"
                className="w-full rounded-md border border-slate-300 bg-white px-2.5 py-1.5 text-sm focus:border-brand-500 focus:ring-2 focus:ring-brand-500 focus:outline-none"
              />
            </div>

            {/* A fixed height keeps the form usable however many employees there are. */}
            <div className="max-h-52 overflow-y-auto">
              {pickerEmployees.length === 0 ? (
                <p className="px-3 py-4 text-sm text-slate-500">No employees match that name.</p>
              ) : (
                <ul className="divide-y divide-slate-100">
                  {pickerEmployees.map((employee) => {
                    const checked = values.employeeIds.includes(employee.id);

                    return (
                      <li key={employee.id}>
                        <label
                          className={`flex cursor-pointer items-center gap-3 px-3 py-2.5 text-sm transition hover:bg-slate-50 ${
                            checked ? "bg-brand-50/60" : ""
                          }`}
                        >
                          <input
                            type="checkbox"
                            checked={checked}
                            onChange={() => toggleEmployee(employee.id)}
                            className="h-4 w-4 rounded border-slate-300 text-brand-600 focus:ring-2 focus:ring-brand-500"
                          />
                          <Avatar employee={employee} />
                          <span className="min-w-0 flex-1">
                            <span className="block truncate font-medium text-slate-900">
                              {fullName(employee)}
                            </span>
                            <span className="block truncate text-xs text-slate-500">
                              {employee.position} · {employee.department}
                            </span>
                          </span>
                        </label>
                      </li>
                    );
                  })}
                </ul>
              )}
            </div>
          </div>

          {employeeError && (
            <p className="mt-1 text-xs font-medium text-red-600" role="alert">
              {employeeError}
            </p>
          )}
        </fieldset>

        {/* --- Complexity: low / medium / high --- */}
        <fieldset>
          <legend className="text-sm font-medium text-slate-700">
            Project complexity
            <span className="ml-0.5 text-red-500" aria-hidden="true">
              *
            </span>
          </legend>

          <div className="mt-2 grid grid-cols-3 gap-2">
            {COMPLEXITY_LEVELS.map((level) => {
              const selected = values.complexity === level;

              return (
                <label
                  key={level}
                  className={`cursor-pointer rounded-lg border px-3 py-2.5 text-center transition ${
                    selected
                      ? "border-brand-500 bg-brand-50 ring-2 ring-brand-500"
                      : "border-slate-300 bg-white hover:bg-slate-50"
                  }`}
                >
                  <input
                    type="radio"
                    name="complexity"
                    value={level}
                    checked={selected}
                    onChange={() => update("complexity", level)}
                    className="sr-only-label"
                  />
                  <span className="block text-sm font-medium text-slate-900 capitalize">
                    {level}
                  </span>
                  <span className="mt-0.5 block text-xs text-slate-500">
                    {COMPLEXITY_HINTS[level]}
                  </span>
                </label>
              );
            })}
          </div>

          {errorFor("complexity") && (
            <p className="mt-1 text-xs font-medium text-red-600" role="alert">
              {errorFor("complexity")}
            </p>
          )}
        </fieldset>

        <Field
          id="startDate"
          label="Start date"
          required
          error={errorFor("startDate")}
          hint="A date today or earlier marks the project as already started."
        >
          {(props) => (
            <input
              {...props}
              type="date"
              value={values.startDate}
              onChange={(event) => update("startDate", event.target.value)}
              className={`${inputClasses} ${borderFor(errorFor("startDate"))}`}
            />
          )}
        </Field>

        {/* LOGIC CHECK: warnings that do not stop the save. */}
        {warnings.length > 0 && (
          <Alert tone="warning" title="Worth checking">
            <ul className={warnings.length > 1 ? "list-inside list-disc" : ""}>
              {warnings.map((warning) => (
                <li key={warning}>{warning}</li>
              ))}
            </ul>
          </Alert>
        )}
      </form>
    </Modal>
  );
}
