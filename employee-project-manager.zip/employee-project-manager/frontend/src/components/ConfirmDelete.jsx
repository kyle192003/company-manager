/**
 * ConfirmDelete.jsx — the "are you sure?" step before an employee is removed.
 *
 * REQUIREMENT: "Delete an Employee."
 * LOGIC CHECK: a project must keep at least one employee. The check runs here
 * too, so the warning appears before the user commits rather than as a failure
 * afterwards — the server still refuses it either way.
 */

import Modal from "./Modal.jsx";
import Button from "./Button.jsx";
import Alert from "./Alert.jsx";
import { fullName } from "../lib/filters.js";
import { findProjectsLeftEmptyBy } from "../lib/validation.js";

export default function ConfirmDelete({ employee, projects, onCancel, onConfirm, busy, error }) {
  // Projects that would be left with nobody on them.
  const blocked = findProjectsLeftEmptyBy(employee.id, projects);
  const canDelete = blocked.length === 0;

  // Projects they are on that have other members — those simply lose one person.
  const otherProjects = projects.filter(
    (project) => project.employeeIds.includes(employee.id) && !blocked.includes(project),
  );

  return (
    <Modal
      title={`Delete ${fullName(employee)}?`}
      onClose={onCancel}
      footer={
        <>
          <Button variant="secondary" onClick={onCancel} disabled={busy}>
            Cancel
          </Button>
          <Button
            variant="danger"
            onClick={onConfirm}
            // Blocked while it would empty a project.
            disabled={!canDelete}
            busy={busy}
            busyLabel="Deleting…"
          >
            Delete employee
          </Button>
        </>
      }
    >
      <div className="space-y-4">
        {/* A refusal that came back from the server, e.g. the data changed meanwhile. */}
        {error && <Alert tone="error">{error}</Alert>}

        {canDelete ? (
          <p className="text-sm text-slate-600">
            This removes them from the directory. It cannot be undone.
          </p>
        ) : (
          // LOGIC CHECK: the delete is refused, with the reason.
          <Alert tone="error" title="This employee cannot be deleted">
            <p>
              They are the only employee on{" "}
              {blocked.map((project, index) => (
                <span key={project.id}>
                  {index > 0 && ", "}
                  <strong>{project.name}</strong>
                </span>
              ))}
              , and a project must have at least one employee.
            </p>
            <p className="mt-1.5">
              Add someone else to {blocked.length === 1 ? "that project" : "those projects"} first.
            </p>
          </Alert>
        )}

        {canDelete && otherProjects.length > 0 && (
          <Alert tone="warning" title="They will be removed from these projects">
            <ul className="mt-1 list-inside list-disc">
              {otherProjects.map((project) => (
                <li key={project.id}>{project.name}</li>
              ))}
            </ul>
            <p className="mt-1.5">
              Each of these keeps at least one other employee, so the projects remain valid.
            </p>
          </Alert>
        )}
      </div>
    </Modal>
  );
}
