/**
 * EmployeeDetails.jsx — the pop-up showing one employee.
 *
 * REQUIREMENT: "View individual employee details."
 *
 * It asks the API for the employee by id rather than reusing the row already on
 * screen, because that endpoint also returns the projects they are assigned to.
 */

import { useEffect, useState } from "react";

import Modal from "./Modal.jsx";
import Button from "./Button.jsx";
import Alert from "./Alert.jsx";
import { StatusBadge, ComplexityBadge } from "./Badge.jsx";
import { describeStart, formatDate } from "../lib/dates.js";
import { fullName } from "../lib/filters.js";

/** One label-and-value pair in the details grid. */
function Detail({ label, children }) {
  return (
    <div>
      <dt className="text-xs font-medium tracking-wide text-slate-500 uppercase">{label}</dt>
      <dd className="mt-0.5 text-sm text-slate-900">{children}</dd>
    </div>
  );
}

export default function EmployeeDetails({ client, employee, onClose, today }) {
  const [details, setDetails] = useState(null);
  const [error, setError] = useState("");

  useEffect(() => {
    // `cancelled` stops a slow response from updating a pop-up that has since
    // been closed, which React would warn about.
    let cancelled = false;

    client
      .getEmployee(employee.id)
      .then((result) => {
        if (!cancelled) setDetails(result);
      })
      .catch((problem) => {
        if (!cancelled) setError(problem.message);
      });

    return () => {
      cancelled = true;
    };
  }, [client, employee.id]);

  return (
    <Modal
      title={fullName(employee)}
      description={`${employee.position} · ${employee.department}`}
      onClose={onClose}
      footer={
        <Button variant="secondary" onClick={onClose}>
          Close
        </Button>
      }
    >
      {error && <Alert tone="error">{error}</Alert>}

      {!details && !error && <p className="text-sm text-slate-500">Loading details…</p>}

      {details && (
        <div className="space-y-6">
          <dl className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <Detail label="Employee ID">
              <code className="rounded bg-slate-100 px-1.5 py-0.5 text-xs">{details.id}</code>
            </Detail>
            <Detail label="Department">{details.department}</Detail>
            <Detail label="Position">{details.position}</Detail>
            <Detail label="Hire date">{formatDate(details.hireDate)}</Detail>
            <div className="sm:col-span-2">
              <Detail label="Email">
                <a href={`mailto:${details.email}`} className="text-brand-600 hover:underline">
                  {details.email}
                </a>
              </Detail>
            </div>
          </dl>

          <div>
            <h3 className="text-sm font-semibold text-slate-900">
              Projects ({details.projects.length})
            </h3>

            {details.projects.length === 0 ? (
              <p className="mt-2 text-sm text-slate-500">
                Not assigned to any project yet.
              </p>
            ) : (
              <ul className="mt-2 space-y-2">
                {details.projects.map((project) => {
                  // LOGIC CHECK: show whether each project has already started.
                  const status = describeStart(project.startDate, today);

                  return (
                    <li
                      key={project.id}
                      className="rounded-lg border border-slate-200 bg-slate-50 px-3 py-2.5"
                    >
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <p className="text-sm font-medium text-slate-900">{project.name}</p>
                        <StatusBadge status={status} />
                      </div>
                      <div className="mt-1.5 flex flex-wrap items-center gap-2 text-xs text-slate-500">
                        <ComplexityBadge complexity={project.complexity} />
                        <span>
                          {formatDate(project.startDate)} · {status.label}
                        </span>
                      </div>
                    </li>
                  );
                })}
              </ul>
            )}
          </div>
        </div>
      )}
    </Modal>
  );
}
