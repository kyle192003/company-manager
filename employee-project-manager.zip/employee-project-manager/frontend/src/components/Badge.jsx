/**
 * Badge.jsx — the small coloured pills used for project status and complexity.
 */

/** Tailwind classes for each badge colour. */
const TONES = {
  green: "bg-emerald-100 text-emerald-800 ring-emerald-600/20",
  amber: "bg-amber-100 text-amber-800 ring-amber-600/20",
  slate: "bg-slate-100 text-slate-700 ring-slate-500/20",
  red: "bg-red-100 text-red-800 ring-red-600/20",
  brand: "bg-brand-100 text-brand-700 ring-brand-600/20",
};

export default function Badge({ tone = "slate", children }) {
  return (
    <span
      className={`inline-flex items-center gap-1 rounded-full px-2.5 py-0.5 text-xs font-medium ring-1 ring-inset ${TONES[tone] ?? TONES.slate}`}
    >
      {children}
    </span>
  );
}

/**
 * LOGIC CHECK: "UI must indicate if a project has already started."
 * Green means under way, amber means still to come.
 */
export function StatusBadge({ status }) {
  return (
    <Badge tone={status.started ? "green" : "amber"}>
      <span aria-hidden="true">{status.started ? "●" : "○"}</span>
      {status.started ? "Started" : "Upcoming"}
    </Badge>
  );
}

/** Low / medium / high, coloured by how demanding the project is. */
export function ComplexityBadge({ complexity }) {
  const tone = { low: "slate", medium: "brand", high: "red" }[complexity] ?? "slate";
  return <Badge tone={tone}>{complexity} complexity</Badge>;
}
