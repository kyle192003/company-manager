/**
 * ProjectsScreen.jsx — screen 2 of 2.
 *
 * REQUIREMENTS on this screen:
 *   - Create new projects, with name, description, employees, complexity, start date
 *   - Search projects by name
 *
 * LOGIC CHECK: every card shows whether its project has already started.
 */

import { useMemo, useState } from "react";

import SearchField from "../components/SearchField.jsx";
import ProjectCard from "../components/ProjectCard.jsx";
import NewProjectForm from "../components/NewProjectForm.jsx";
import Button from "../components/Button.jsx";
import Alert from "../components/Alert.jsx";
import { filterProjects, sortProjects } from "../lib/filters.js";
import { hasStarted } from "../lib/dates.js";

export default function ProjectsScreen({
  client,
  projects,
  employees,
  today,
  onDataChanged,
  onNotify,
}) {
  const [search, setSearch] = useState("");
  const [creating, setCreating] = useState(false);
  // Warnings the server sent back with a project it accepted.
  const [warnings, setWarnings] = useState([]);

  /** The cards to show, newest start date first. */
  const visible = useMemo(
    () => sortProjects(filterProjects(projects, { search })),
    [projects, search],
  );

  /** A count for the summary line: how many are under way. */
  const startedCount = useMemo(
    () => projects.filter((project) => hasStarted(project.startDate, today)).length,
    [projects, today],
  );

  async function handleCreated(project) {
    setCreating(false);
    setWarnings(project.warnings ?? []);
    onNotify(`"${project.name}" was created.`);
    await onDataChanged();
  }

  return (
    <section aria-labelledby="projects-heading">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h2 id="projects-heading" className="text-xl font-semibold text-slate-900">
            Projects
          </h2>
          <p className="mt-1 text-sm text-slate-500">
            {search
              ? `Showing ${visible.length} of ${projects.length} projects`
              : `${projects.length} projects · ${startedCount} already started`}
          </p>
        </div>

        <Button onClick={() => setCreating(true)}>+ New project</Button>
      </div>

      <div className="mt-5">
        <SearchField
          id="project-search"
          label="Search projects by name"
          value={search}
          onChange={setSearch}
          placeholder="Search projects by name…"
          resultCount={visible.length}
        />
      </div>

      {/* Warnings about the project that was just created, e.g. a past start date. */}
      {warnings.length > 0 && (
        <div className="mt-4">
          <Alert tone="warning" title="The project was created, with a note" onDismiss={() => setWarnings([])}>
            <ul className={warnings.length > 1 ? "list-inside list-disc" : ""}>
              {warnings.map((warning) => (
                <li key={warning}>{warning}</li>
              ))}
            </ul>
          </Alert>
        </div>
      )}

      {/* --- The cards --- */}
      <div className="mt-5">
        {visible.length === 0 ? (
          <div className="rounded-xl border border-dashed border-slate-300 bg-white px-6 py-12 text-center">
            <p className="text-sm font-medium text-slate-900">No projects match your search.</p>
            <p className="mt-1 text-sm text-slate-500">
              Try a different name, or create a new project.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-3">
            {visible.map((project) => (
              <ProjectCard key={project.id} project={project} today={today} />
            ))}
          </div>
        )}
      </div>

      {creating && (
        <NewProjectForm
          client={client}
          employees={employees}
          projects={projects}
          today={today}
          onClose={() => setCreating(false)}
          onCreated={handleCreated}
        />
      )}
    </section>
  );
}
