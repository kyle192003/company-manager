/**
 * EmployeeDirectory.jsx — screen 1 of 2.
 *
 * REQUIREMENTS on this screen:
 *   - Display a comprehensive list of employees
 *   - View individual employee details   (opens a pop-up)
 *   - Filter employees by department
 *   - Search employees by name
 *   - Add an employee                    (opens a pop-up)
 *   - Delete an employee                 (opens a confirmation pop-up)
 *
 * The screen holds the search text and the chosen department, and works out the
 * visible rows from them. The employee list itself is loaded once by App.jsx.
 */

import { useMemo, useState } from "react";

import SearchField from "../components/SearchField.jsx";
import EmployeeTable from "../components/EmployeeTable.jsx";
import EmployeeDetails from "../components/EmployeeDetails.jsx";
import AddEmployeeForm from "../components/AddEmployeeForm.jsx";
import ConfirmDelete from "../components/ConfirmDelete.jsx";
import Button from "../components/Button.jsx";
import { ALL_DEPARTMENTS, filterEmployees, sortEmployees, fullName } from "../lib/filters.js";

export default function EmployeeDirectory({
  client,
  employees,
  projects,
  departments,
  today,
  onDataChanged,
  onNotify,
}) {
  const [search, setSearch] = useState("");
  const [department, setDepartment] = useState(ALL_DEPARTMENTS);

  // Which pop-up is open, if any.
  const [viewing, setViewing] = useState(null);
  const [adding, setAdding] = useState(false);
  const [deleting, setDeleting] = useState(null);

  const [deleteBusy, setDeleteBusy] = useState(false);
  const [deleteError, setDeleteError] = useState("");

  /**
   * The rows to show. useMemo keeps this from re-running on every render —
   * only when the list, the search text or the department actually change.
   */
  const visible = useMemo(
    () => sortEmployees(filterEmployees(employees, { search, department })),
    [employees, search, department],
  );

  /** Runs after the Add Employee pop-up saves someone. */
  async function handleCreated(employee) {
    setAdding(false);
    onNotify(`${fullName(employee)} was added to the directory.`);
    await onDataChanged();
  }

  /** Runs when the confirmation pop-up is accepted. */
  async function handleDeleteConfirmed() {
    setDeleteBusy(true);
    setDeleteError("");

    try {
      await client.deleteEmployee(deleting.id);
      const name = fullName(deleting);
      setDeleting(null);
      onNotify(`${name} was removed from the directory.`);
      await onDataChanged();
    } catch (problem) {
      // LOGIC CHECK: this is where the server's "would empty a project" refusal
      // is shown, in case the data changed since the pop-up was opened.
      setDeleteError(problem.message);
    } finally {
      setDeleteBusy(false);
    }
  }

  const isFiltered = search !== "" || department !== ALL_DEPARTMENTS;

  return (
    <section aria-labelledby="directory-heading">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h2 id="directory-heading" className="text-xl font-semibold text-slate-900">
            Employee directory
          </h2>
          <p className="mt-1 text-sm text-slate-500">
            {isFiltered
              ? `Showing ${visible.length} of ${employees.length} employees`
              : `${employees.length} employees`}
          </p>
        </div>

        <Button onClick={() => setAdding(true)}>+ Add employee</Button>
      </div>

      {/* --- Search and filter --- */}
      <div className="mt-5 flex flex-col gap-3 sm:flex-row">
        <SearchField
          id="employee-search"
          label="Search employees by name"
          value={search}
          onChange={setSearch}
          placeholder="Search employees by name…"
          resultCount={visible.length}
        />

        <div className="sm:w-56">
          <label htmlFor="department-filter" className="sr-only-label">
            Filter by department
          </label>
          <select
            id="department-filter"
            value={department}
            onChange={(event) => setDepartment(event.target.value)}
            className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 shadow-sm focus:border-brand-500 focus:ring-2 focus:ring-brand-500 focus:outline-none"
          >
            <option value={ALL_DEPARTMENTS}>All departments</option>
            {departments.map((name) => (
              <option key={name} value={name}>
                {name}
              </option>
            ))}
          </select>
        </div>

        {isFiltered && (
          <Button
            variant="secondary"
            onClick={() => {
              setSearch("");
              setDepartment(ALL_DEPARTMENTS);
            }}
          >
            Clear
          </Button>
        )}
      </div>

      {/* --- The list --- */}
      <div className="mt-5">
        <EmployeeTable
          employees={visible}
          onView={setViewing}
          onDelete={(employee) => {
            setDeleteError("");
            setDeleting(employee);
          }}
        />
      </div>

      {/* --- Pop-ups --- */}
      {viewing && (
        <EmployeeDetails
          client={client}
          employee={viewing}
          today={today}
          onClose={() => setViewing(null)}
        />
      )}

      {adding && (
        <AddEmployeeForm
          client={client}
          employees={employees}
          departments={departments}
          onClose={() => setAdding(false)}
          onCreated={handleCreated}
        />
      )}

      {deleting && (
        <ConfirmDelete
          employee={deleting}
          projects={projects}
          busy={deleteBusy}
          error={deleteError}
          onCancel={() => setDeleting(null)}
          onConfirm={handleDeleteConfirmed}
        />
      )}
    </section>
  );
}
