/**
 * main.jsx — where the app starts.
 *
 * It creates the data client once (the real API, or the in-memory demo one) and
 * hands it to App. Everything below App receives that client as a prop, which is
 * what lets the tests pass a fake one in its place.
 */

import { StrictMode } from "react";
import { createRoot } from "react-dom/client";

import App from "./App.jsx";
import { createClient } from "./api/client.js";
import "./index.css";

const client = createClient();

createRoot(document.getElementById("root")).render(
  <StrictMode>
    <App client={client} />
  </StrictMode>,
);
