/**
 * App.jsx — the one page, and the switcher between the two screens.
 *
 * The brief asks for an employee directory and a project list. Both live here,
 * and the tabs at the top swap between them. Everything else — employee details,
 * the two forms, the delete confirmation — opens as a pop-up on top, so the app
 * never leaves this page.
 *
 * App is also the only place that loads data. Both screens receive the lists as
 * props and call onDataChanged() after a save, which reloads them from one place.
 */

import { useCallback, useEffect, useState } from "react";

import Tabs from "./components/Tabs.jsx";
import Alert from "./components/Alert.jsx";
import Button from "./components/Button.jsx";
import EmployeeDirectory from "./screens/EmployeeDirectory.jsx";
import ProjectsScreen from "./screens/ProjectsScreen.jsx";
import { today as todayString } from "./lib/dates.js";

/** The two screens, in the order the tabs show them. */
const SCREENS = [
  { id: "employees", label: "Employee Directory" },
  { id: "projects", label: "Projects" },
];

export default function App({ client }) {
  const [activeScreen, setActiveScreen] = useState(SCREENS[0].id);

  // The data every screen works from.
  const [employees, setEmployees] = useState([]);
  const [projects, setProjects] = useState([]);
  const [departments, setDepartments] = useState([]);
  const [today, setToday] = useState(todayString());

  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState("");
  // A short confirmation after a save or a delete.
  const [notice, setNotice] = useState("");

  /**
   * Loads everything the app needs.
   * useCallback keeps the same function between renders, so the effect below
   * does not re-run on every render.
   */
  const loadAll = useCallback(async () => {
    setLoadError("");

    try {
      // All three at once rather than one after another.
      const [meta, employeeList, projectList] = await Promise.all([
        client.getMeta(),
        client.getEmployees(),
        client.getProjects(),
      ]);

      setDepartments(meta.departments);
      setToday(meta.today ?? todayString());
      setEmployees(employeeList);
      setProjects(projectList);
    } catch (problem) {
      // LOGIC CHECK: tell the user the API is unreachable, rather than showing
      // an empty directory as though there were simply no employees.
      setLoadError(problem.message);
    } finally {
      setLoading(false);
    }
  }, [client]);

  useEffect(() => {
    loadAll();
  }, [loadAll]);

  /** Shows a confirmation that fades out on its own. */
  const notify = useCallback((message) => {
    setNotice(message);
    const timer = setTimeout(() => setNotice(""), 4000);
    return () => clearTimeout(timer);
  }, []);

  const tabs = SCREENS.map((screen) => ({
    ...screen,
    count: screen.id === "employees" ? employees.length : projects.length,
  }));

  return (
    <div className="min-h-screen bg-slate-50">
      <header className="border-b border-slate-200 bg-white">
        <div className="mx-auto max-w-6xl px-4 py-6 sm:px-6">
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">
            Employee &amp; Project Manager
          </h1>
          <p className="mt-1 text-sm text-slate-500">
            Browse the directory and manage project assignments.
          </p>

          {/* The switcher between the two screens. */}
          <div className="mt-5">
            <Tabs tabs={tabs} activeId={activeScreen} onChange={setActiveScreen} />
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-6xl px-4 py-6 sm:px-6 sm:py-8">
        {/* Shown only on the GitHub Pages build, where there is no server. */}
        {client.isDemo && (
          <div className="mb-5">
            <Alert tone="info" title="Demo mode">
              This deployed copy has no backend, so changes are kept in the browser only and are
              lost when the page reloads. Run it locally to save to the JSON database.
            </Alert>
          </div>
        )}

        {notice && (
          <div className="mb-5">
            <Alert tone="success" onDismiss={() => setNotice("")}>
              {notice}
            </Alert>
          </div>
        )}

        {loadError && (
          <div className="mb-5">
            <Alert tone="error" title="Could not load the data">
              <p>{loadError}</p>
              <div className="mt-2">
                <Button variant="secondary" onClick={loadAll}>
                  Try again
                </Button>
              </div>
            </Alert>
          </div>
        )}

        {loading ? (
          <p className="py-16 text-center text-sm text-slate-500">Loading…</p>
        ) : (
          // Only the selected screen is rendered; the other is unmounted.
          <div
            role="tabpanel"
            id={`panel-${activeScreen}`}
            aria-labelledby={`tab-${activeScreen}`}
          >
            {activeScreen === "employees" ? (
              <EmployeeDirectory
                client={client}
                employees={employees}
                projects={projects}
                departments={departments}
                today={today}
                onDataChanged={loadAll}
                onNotify={notify}
              />
            ) : (
              <ProjectsScreen
                client={client}
                projects={projects}
                employees={employees}
                today={today}
                onDataChanged={loadAll}
                onNotify={notify}
              />
            )}
          </div>
        )}
      </main>

      <footer className="mx-auto max-w-6xl px-4 pb-10 text-center text-xs text-slate-400 sm:px-6">
        React + Vite + Tailwind front end · Express + JSON file back end
      </footer>
    </div>
  );
}
