/**
 * vite.config.js — build, dev server and test configuration.
 *
 * BONUS: Tailwind is wired in here as a Vite plugin (Tailwind v4 needs no
 * separate config file or PostCSS setup).
 */

import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";

export default defineConfig({
  plugins: [react(), tailwindcss()],

  /**
   * GitHub Pages serves the site from /<repository-name>/, not from the domain
   * root, so the CI workflow sets VITE_BASE_PATH before building. Locally it
   * stays "/".
   */
  base: process.env.VITE_BASE_PATH || "/",

  server: {
    port: 5173,
    open: true,
  },

  /** Vitest settings. `npm test` runs these. */
  test: {
    // Components need a fake browser to render into.
    environment: "jsdom",
    // Lets tests use describe/it/expect without importing them.
    globals: true,
    // Adds the extra matchers such as toBeInTheDocument().
    setupFiles: "./src/tests/setup.js",
  },
});
