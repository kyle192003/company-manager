/**
 * generate-avatars.mjs — draws the placeholder avatars in public/avatars/.
 *
 * Run it with `npm run avatars` from the frontend folder.
 *
 * WHY generate them instead of linking to a photo service: the avatars are part
 * of the app, so they must work with no internet, behind a corporate firewall,
 * and on GitHub Pages. These are plain SVG files — a few hundred bytes each,
 * no network request, nothing to break.
 *
 * Each employee id always produces the same face, so the directory looks the
 * same every time it loads.
 */

import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const here = path.dirname(fileURLToPath(import.meta.url));
const outputFolder = path.join(here, "..", "public", "avatars");

/** The palettes a face is assembled from. */
const SKIN = ["#F8D5C2", "#F0C2A2", "#D9A06B", "#B57A4A", "#8D5524", "#6B3F22"];
const HAIR = ["#2B1B17", "#4A312C", "#7B5233", "#B55239", "#D9B36C", "#171717", "#8A8A8A"];
const SHIRT = ["#4F46E5", "#0EA5E9", "#059669", "#DC2626", "#D97706", "#7C3AED", "#0F766E"];
const BACKDROP = ["#E0E7FF", "#E0F2FE", "#D1FAE5", "#FEE2E2", "#FEF3C7", "#EDE9FE", "#CCFBF1"];

/**
 * The hair shapes. The head is an ellipse centred at (100, 86) with rx 34 and
 * ry 37, so it spans x 66–134 and y 49–123. Each shape starts with the top half
 * of that same ellipse, then closes with its own hairline, which is what keeps
 * the hair sitting exactly on the skull.
 */
const HAIRSTYLES = {
  // A rounded cap covering the top of the head.
  short: (colour) =>
    `<path d="M66 86A34 37 0 0 1 134 86C134 72 120 63 100 63S66 72 66 86Z" fill="${colour}"/>`,

  // Shorter at the sides, with height on top.
  fade: (colour) =>
    `<path d="M69 82A34 37 0 0 1 131 82C129 70 118 61 100 61S71 70 69 82Z" fill="${colour}"/>`,

  // A side parting, swept across the forehead.
  parted: (colour) =>
    `<path d="M66 86A34 37 0 0 1 134 86C133 76 126 70 118 68c-9 4-20 6-31 9-10 3-17 5-21 9Z" fill="${colour}"/>`,

  // A tight, textured cut — the scalloped hairline reads as curls.
  curly: (colour) =>
    `<path d="M66 86A34 37 0 0 1 134 86c0-6-4-6-7-9s-5-8-10-8-7 3-11 3-7-4-12-4-8 4-12 4-6-3-11-3-5 5-8 8-6 3-6 9Z" fill="${colour}"/>`,

  // Long hair falling past the jaw on both sides.
  long: (colour) =>
    `<path d="M66 86A34 37 0 0 1 134 86v38a6 6 0 0 1-12 0V95c0-13-10-21-22-21s-22 8-22 21v29a6 6 0 0 1-12 0Z" fill="${colour}"/>`,

  // Tied back, with a bun behind the crown.
  bun: (colour) =>
    `<circle cx="100" cy="44" r="14" fill="${shade(colour, -14)}"/>` +
    `<path d="M66 86A34 37 0 0 1 134 86C134 70 119 60 100 60S66 70 66 86Z" fill="${colour}"/>`,

  // No hair on top.
  bald: () => "",
};

/** Turns a string into a stable number, so one id always picks the same face. */
function hash(text) {
  let value = 0;
  for (const character of text) {
    value = (value * 31 + character.codePointAt(0)) % 100_000;
  }
  return value;
}

/** Picks one item from a list, using the hash so the choice never changes. */
function pick(list, seed, offset) {
  return list[(seed + offset) % list.length];
}

/** Builds one avatar as an SVG string. */
export function buildAvatar(id) {
  const seed = hash(id);

  const skin = pick(SKIN, seed, 0);
  // Hair has to stand out from the skin, or the avatar just looks bald at the
  // 36px size the directory shows it at.
  const hair = pickContrastingHair(seed, skin);
  const shirt = pick(SHIRT, seed, 5);
  const backdrop = pick(BACKDROP, seed, 5); // same offset as the shirt, so they coordinate

  // Bald is deliberately rare rather than one option in the rotation — an even
  // share would leave roughly a sixth of the directory with no hair.
  const withHair = Object.keys(HAIRSTYLES).filter((name) => name !== "bald");
  const hairstyle = seed % 11 === 0 ? "bald" : withHair[(seed + 2) % withHair.length];

  const hasGlasses = (seed + 1) % 4 === 0;
  const hasBeard = (seed + 7) % 5 === 0 && hairstyle !== "long" && hairstyle !== "bun";

  // A slightly darker shade of the shirt, for the collar.
  const collar = shade(shirt, -18);

  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 200" width="200" height="200" role="img" aria-label="Illustrated avatar">
  <circle cx="100" cy="100" r="100" fill="${backdrop}"/>

  <!-- shoulders -->
  <path d="M38 200c0-30 28-47 62-47s62 17 62 47Z" fill="${shirt}"/>
  <path d="M86 156h28l-14 18Z" fill="${collar}"/>

  <!-- neck -->
  <path d="M87 116h26v30a13 13 0 0 1-26 0Z" fill="${shade(skin, -14)}"/>

  <!-- head -->
  <ellipse cx="100" cy="86" rx="34" ry="37" fill="${skin}"/>
  <!-- ears -->
  <circle cx="66" cy="90" r="6.5" fill="${shade(skin, -10)}"/>
  <circle cx="134" cy="90" r="6.5" fill="${shade(skin, -10)}"/>

  <!-- beard sits under the hair but over the jaw, and before the mouth so the
       mouth is drawn on top of it rather than hidden behind it -->
  ${hasBeard ? `<path d="M67 90c0 22 15 33 33 33s33-11 33-33c3 22-6 39-18 43-5 2-10 2-15 2s-10 0-15-2c-12-4-21-21-18-43Z" fill="${hair}"/>` : ""}

  ${HAIRSTYLES[hairstyle](hair)}

  <!-- eyebrows -->
  <path d="M81 79q7-4 14 0M105 79q7-4 14 0" stroke="${shade(hair, 10)}" stroke-width="3" stroke-linecap="round" fill="none"/>

  <!-- eyes -->
  <circle cx="88" cy="89" r="3.6" fill="#2A2A33"/>
  <circle cx="112" cy="89" r="3.6" fill="#2A2A33"/>

  <!-- mouth -->
  <path d="M92 105q8 7 16 0" stroke="#7F3B33" stroke-width="3" stroke-linecap="round" fill="none"/>

  ${
    hasGlasses
      ? `<g stroke="#334155" stroke-width="2.5" fill="none">
    <circle cx="88" cy="89" r="10.5"/><circle cx="112" cy="89" r="10.5"/>
    <path d="M98.5 89h3M77.5 86l-9-2M122.5 86l9-2"/>
  </g>`
      : ""
  }
</svg>
`;
}

/** Roughly how bright a colour looks, 0 (black) to 255 (white). */
function brightness(hex) {
  const value = Number.parseInt(hex.slice(1), 16);
  // Green contributes most to perceived brightness, blue least.
  return (((value >> 16) & 255) * 299 + ((value >> 8) & 255) * 587 + (value & 255) * 114) / 1000;
}

/**
 * Picks a hair colour far enough from the skin tone to be visible.
 * Walks the palette from the seeded starting point and takes the first one with
 * enough difference, falling back to the furthest apart if none qualifies.
 */
function pickContrastingHair(seed, skin) {
  const skinBrightness = brightness(skin);
  const start = seed % HAIR.length;

  for (let step = 0; step < HAIR.length; step += 1) {
    const candidate = HAIR[(start + step) % HAIR.length];
    if (Math.abs(brightness(candidate) - skinBrightness) >= 45) return candidate;
  }

  return [...HAIR].sort(
    (a, b) =>
      Math.abs(brightness(b) - skinBrightness) - Math.abs(brightness(a) - skinBrightness),
  )[0];
}

/** Lightens or darkens a hex colour by the given amount. */
function shade(hex, amount) {
  const value = Number.parseInt(hex.slice(1), 16);
  const clamp = (channel) => Math.max(0, Math.min(255, channel + amount));

  const red = clamp((value >> 16) & 255);
  const green = clamp((value >> 8) & 255);
  const blue = clamp(value & 255);

  return `#${((red << 16) | (green << 8) | blue).toString(16).padStart(6, "0")}`;
}

/** Writes one SVG per employee id passed on the command line, or emp-1…emp-12. */
function main() {
  const ids =
    process.argv.slice(2).length > 0
      ? process.argv.slice(2)
      : Array.from({ length: 12 }, (_, index) => `emp-${index + 1}`);

  fs.mkdirSync(outputFolder, { recursive: true });

  for (const id of ids) {
    fs.writeFileSync(path.join(outputFolder, `${id}.svg`), buildAvatar(id), "utf8");
  }

  console.log(`Wrote ${ids.length} avatars to ${outputFolder}`);
}

// Only run when called directly, so the tests can import buildAvatar().
if (process.argv[1] && path.resolve(process.argv[1]) === path.resolve(fileURLToPath(import.meta.url))) {
  main();
}
