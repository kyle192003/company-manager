# Frontend

React 19 + Vite + Tailwind v4.

```bash
npm install
npm run dev      # http://localhost:5173
npm test         # Vitest
npm run build    # production build into dist/
```

The API must be running — `npm start` in `../backend` — or the page shows
"Could not load the data" with a Try again button.

## What each file does

| Path | Job |
| --- | --- |
| `src/main.jsx` | Start-up. Creates the API client and renders `App`. |
| `src/App.jsx` | The page: loads the data and switches between the two screens. |
| `src/screens/EmployeeDirectory.jsx` | Screen 1 — the list, search, filter and the buttons. |
| `src/screens/ProjectsScreen.jsx` | Screen 2 — the project cards and search. |
| `src/components/` | The pieces both screens share, one job each. |
| `src/lib/validation.js` | The form rules. **The logic checks live here.** |
| `src/lib/dates.js` | Whether a project has started, and how it is worded. |
| `src/lib/filters.js` | Search and department filtering. |
| `src/api/httpClient.js` | Talks to the Express API. |
| `src/api/demoClient.js` | The in-memory stand-in used by the GitHub Pages build. |
| `src/api/client.js` | Picks between those two. |

## Why the client is passed as a prop

`App` receives its API client from `main.jsx` and hands it down. Nothing below knows
whether it is talking to a real server, so the tests pass a fake one in
(`src/tests/fixtures.js`) and the deployed demo passes an in-memory one. No mocking of
`fetch`, and no network in the test suite.

## Tailwind

Tailwind v4 is configured entirely from CSS. `src/index.css` imports it and defines the
brand colours in an `@theme` block; the Vite plugin in `vite.config.js` does the rest.
There is no `tailwind.config.js` and no PostCSS setup.

## Environment variables

Both are optional. Copy `.env.example` to `.env` to change them.

| Variable | Default | Does |
| --- | --- | --- |
| `VITE_API_URL` | `http://localhost:4000` | Where the API is. |
| `VITE_DEMO_MODE` | unset | `true` runs without a backend, using in-memory data. |
| `VITE_BASE_PATH` | `/` | Sub-path the site is served from. CI sets this for GitHub Pages. |
